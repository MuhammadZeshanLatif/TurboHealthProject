import React from "react";
import PropTypes from "prop-types";

const shapes = { circle: "rounded-[50%]", round: "rounded-[10px]" };
const variants = {
  fill: {
    white_A700: "bg-white-A700 text-black-900",
    blue_900: "bg-blue-900 text-white-A700",
    pink_600: "bg-pink-600 text-white-A700",
  },
};
const sizes = {
  xs: "p-[4px]",    // Adjusted for extra small size
  sm: "p-2",        // Adjusted for small size
  md: "p-3",        // Adjusted for medium size
  lg: "p-[12px]",   // Adjusted for large size
  xl: "p-[15px] sm:px-3", // Adjusted for extra large size
};

const Button = ({
  children,
  className = "",
  leftIcon,
  rightIcon,
  shape = "",
  size = "",
  variant = "",
  color = "",
  ...restProps
}) => {
  return (
    <button
      className={`${className} ${(shape && shapes[shape]) || ""} ${
        (size && sizes[size]) || ""
      } ${(variant && variants[variant]?.[color]) || ""}`}
      {...restProps}
    >
      {!!leftIcon && leftIcon}
      {children}
      {!!rightIcon && rightIcon}
    </button>
  );
};

Button.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  shape: PropTypes.oneOf(["circle", "round"]),
  size: PropTypes.oneOf(["xs", "sm", "md", "lg", "xl"]),
  variant: PropTypes.oneOf(["fill"]),
  color: PropTypes.oneOf(["white_A700", "blue_900", "pink_600"]),
};

export { Button };
