import React from 'react'
import PropTypes from 'prop-types';
import './index.css';

 const HorizontalLine = () => {
    const ActiveLine = ({ isActive }) => {
        const lineClass = `h-1 w-[19rem] ${isActive ? 'bg-active' : 'bg-inactive opacity-21'} rounded-full mb-2`;

        return <div className={lineClass}></div>;
    };

    ActiveLine.propTypes = {
        isActive: PropTypes.bool.isRequired,
    };

    return (
        <>
            <div className="flex items-center justify-center mt-9">
                <div className="flex space-x-2">
                    <ActiveLine isActive={false} />
                    <ActiveLine isActive={true} />
                    <ActiveLine isActive={false} />
                    <ActiveLine isActive={false} />
                </div>
            </div>
        </>
    )
}

export default HorizontalLine;