import React from "react";

import { Img, Text } from "components";

const Slide169OneShadow = (props) => {
  return (
    <>
      <div className={props.className}>
        <Img
          className="h-[180px] sm:h-auto object-cover rounded-tl-[12px] rounded-tr-[12px] w-full"
          alt="rectangleFour"
          src={props?.userimage}
        />
        <div className="flex flex-col gap-5 h-full items-start justify-between sm:px-5 px-6 py-8 w-full">
          <div className="flex flex-col gap-5 h-[170px] md:h-auto items-start justify-start w-full">
            <div className="flex flex-col gap-2 items-start justify-start w-full">
              <Text
                className="text-center text-pink-600 text-[12px] tracking-[0.80px] uppercase w-auto"
                size="txtPoppinsSemiBold14"
              >
                {props?.article}
              </Text>
              <Text
                className="leading-[140.00%] max-w-[312px] md:max-w-full text-gray-900_02 text-[16px]"
                size="txtMontserratBold20Gray90002"
              >
                {props?.guidefordesigniOne}
              </Text>
            </div>
            <Text
              className="leading-[180.00%] max-w-[312px] md:max-w-full text-[12px] text-gray-900_8e"
              size="txtMontserratRegular16Gray9008e"
            >
              {props?.inthisarticle}
            </Text>
          </div>

          <div className="flex flex-row gap-3 items-start justify-start w-auto">
            <div className="flex flex-col h-12 items-center justify-start w-12">
              <Img
                className="h-12 md:h-auto rounded-[50%] w-12"
                src="images/img_ellipse4.png"
                alt="ellipseFour"
              />
            </div>
            <div className="flex flex-col gap-[5px] items-start justify-start w-auto">
              <Text
                className="text-gray-900_02 text-sm w-auto"
                size="txtPoppinsSemiBold14Gray90002"
              >
                {props?.username}
              </Text>
              <Text
                className="text-gray-900_8e text-xs w-auto"
                size="txtPoppinsRegular12"
              >
                {props?.userinfo}
              </Text>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

Slide169OneShadow.defaultProps = {
  userimage: "images/img_rectangle4.png",
  article: "Article",
  guidefordesigniOne: (
    <>
      Guide for designing better
      <br />
      mobile apps typography
    </>
  ),
  inthisarticle:
    "In this article, I won’t talk about the general concepts of typography, which can be used both in print...",
  username: "Kristin Watson",
  userinfo: "Jun 27, 2020 · 6 min read",
};

export default Slide169OneShadow;
