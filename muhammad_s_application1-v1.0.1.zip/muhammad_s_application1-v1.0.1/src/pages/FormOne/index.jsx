import React from "react";
//  import Button  from "components";
import { Button, CheckBox, Img, Radio, RadioGroup, Text } from "components";
import Footer from "components/Footer";
import Header from "components/Header";
import HorizontalLine from 'components/HorizontalLine/index'
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import './index.css';
import { useLocation } from 'react-router-dom';


const FormOnePage = () => {
  const nevigate = useNavigate()
  const location = useLocation();
  const { state } = location;
  console.log(state)
  const [isClicked, setIsClicked] = useState(false);
  const [showPopupSpouse, setShowPopupSpouse] = useState(false);
  const [showPopupDependent, setShowPopupSpouseDependent] = useState(false);
  const [popups, setPopups] = useState([]);
  const handleDependents = () => {
    const popupKey = Date.now().toString();
    setPopups((prevPopups) => [...prevPopups, popupKey]);
  };
  const canCellDependents = (popupKey) => {
    setPopups((prevPopups) => prevPopups.filter((key) => key !== popupKey));
  };
  const handleSpouse = () => {
    setShowPopupSpouse(true);
  };

  const canCellSpouse = () => {
    setShowPopupSpouse(false);
  };
  const handleDependent = () => {
    setShowPopupSpouseDependent(true);
  };

  const canCellDependent = () => {
    setShowPopupSpouseDependent(false);
  };

  const handleSubmit = () => {
    showPopup(!showPopup)
  };

  const handleClick = () => {

    setIsClicked(!isClicked);
    console.log("hello")
  };
  // const [isPopupOpen, setIsPopupOpen] = useState(false);

  // const openPopup = () => {
  //   setIsPopupOpen(true);
  // };

  // const closePopup = () => {
  //   setIsPopupOpen(false);
  // };

  const [applicant, setApplicant] = useState({
    applicant_Name: '',
    applicant_DOB: '',
    gender: 'M',
    imatobaccouser: false,
    catigory:state.catigory,
    zipCode:state.zipCode,
    countryIndex:state.tindex
  });

  const applicantData = (e) => {
    if (e) {
      const { name, value, type, checked } = e.target || {};

      if (name !== undefined) {
        setApplicant((prevApplicant) => {
          if (type === 'checkbox') {
            return {
              ...prevApplicant,
              [name]: checked,
            };
          } else {
            return {
              ...prevApplicant,
              [name]: value,
            };
          }
        });
      }
    }
  };

  useEffect(() => {
    console.log('Applicant Data:', {
      name: applicant.applicant_Name,
      'D.O.B': applicant.applicant_DOB,
      gender: applicant.gender,
      tobacoUser: applicant.imatobaccouser,
      catigory:state.catigory,
      zipCode:state.zipCode,
      countryIndex:state.tindex
    });
  }, [applicant]);


  return (
    <>
      <Header />
      <div className="bg-white-A700 flex flex-col font-montserrat items-center justify-end mx-auto pt-1.5 w-full">
        <HorizontalLine />

        <div className="flex flex-col items-center justify-center mt-[51px] md:px-5 w-[21%] md:w-full">
          <div className="flex flex-col gap-[11px] items-center justify-start w-full">
            <Text
              className="sm:text-[21px] md:text-[23px] text-center text-gray-800 text-lg tracking-[-0.55px]"
              size="txtMontserratSemiBold25"
            >
              Let’s add members to your plan.
            </Text>
            <Text
              className="leading-[143.50%] sm:text-[21px] md:text-[23px] text-center text-gray-600 text-lg tracking-[-0.55px] w-[97%] sm:w-full"
              size="txtMontserratMedium25Gray600"
            >
              Who are you buying health insurance for today?
            </Text>
          </div>
        </div>


        {/* <div>
          <button onClick={openPopup} className="bg-blue-500 text-white py-2 px-4 rounded">
            Open Popup
          </button>

          {isPopupOpen && (
            <div className="fixed inset-0 z-50 flex items-center justify-center">
              <div className="absolute inset-0 bg-gray-800 opacity-75"></div>
              <div className="z-50 bg-white p-6 rounded-lg shadow-lg">
                <div className="flex justify-end">
                  <span onClick={closePopup} className="cursor-pointer text-gray-500 hover:text-gray-700">
                    &times;
                  </span>
                </div>
                <div className="mt-4">
                  <p className="text-lg">This is your popup content.</p>
                </div>
              </div>
            </div>
          )}
        </div> */}





        <div className="flex flex-col gap-11 items-center justify-start mt-[90px] md:px-5 w-[32%] md:w-full">
          {/* Add me  */}
          <div className="bg-white-A700 border border-pink-600 border-solid flex flex-col font-roboto items-center justify-end p-11 md:px-10 sm:px-5 rounded-[19px] shadow-bs3 w-full">


            <div className="flex flex-col gap-[30px] items-start justify-start min-w-full w-auto sm:w-full">
              <div className="flex flex-row gap-1.5 items-center justify-start w-[30%] md:w-full">
                <div className="bg-gray-100 text-[black] flex flex-row items-start justify-end min-h-[40px] min-w-[40px] p-[10px] rounded-[50%]">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    className="h-6 w-6 ml-auto cursor-pointer"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M5 12h14m-7 7v-14"
                    />
                  </svg>
                </div>

                <Text
                  className="text-[25px] sm:text-[31px] md:text-[33px] text-blue-700 font-bold"
                  size="txtRobotoRomanSemiBold35"
                >
                  ME
                </Text>
              </div>
              <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                <Text
                  className="text-[15px] text-gray-500_01"
                  size="txtRobotoRomanRegular15"
                >
                  Name
                </Text>
                <div className="relative bg-gray-200 flex items-center rounded-md w-[100%] sm:w-full p-3">
                  <input
                    type="text"
                    placeholder="Name"
                    className="bg-transparent w-full outline-none focus:outline-none border-none"
                    name="applicant_Name"
                    onChange={applicantData}
                  />
                </div>
              </div>
              <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                <Text
                  className="text-[15px] text-gray-500_01"
                  size="txtRobotoRomanRegular15"
                >
                  Date of Birth
                </Text>
                <div className="relative bg-gray-200 flex items-center rounded-md w-[100%] sm:w-full p-3">
                  <input
                    type="date"
                    placeholder="Date of Birth"
                    className="bg-transparent w-full outline-none focus:outline-none border-none"
                    name="applicant_DOB"
                    onChange={applicantData}
                  />
                </div>
              </div>


              <div className="flex flex-col gap-[13px] items-start justify-start w-[31%] md:w-full">
                <Text
                  className="text-[15px] text-gray-500_01"
                  size="txtRobotoRomanRegular15"
                >
                  Gender
                </Text>
                <RadioGroup
                  className="flex flex-col w-full"
                  onChange={applicantData}
                  name="radiogroupmale2"
                >
                  <Radio
                    value="M"
                    className="leading-[normal] sm:pr-5 text-blue_gray-900_02 text-left text-sm"
                    inputClassName="bg-white-A700  border border-blue-900 border-solid h-4 mr-[5px] rounded-[13px] w-4"
                    checked={applicant.gender === 'Male'}
                    aria-checked={applicant.gender === 'Male'}
                    name="gender"
                    label="Male"
                    id="M"
                  ></Radio>
                  <Radio
                    value="F"
                    className="leading-[normal] mt-4 sm:pr-5 text-blue_gray-900_02 text-left text-sm"
                    inputClassName="bg-white-A700 border border-blue-900 border-solid h-4 mr-[5px] rounded-[13px] w-4"
                    checked={applicant.gender === 'Female'}
                    name="gender"
                    label="Female"
                    id="F"
                  ></Radio>
                </RadioGroup>
              </div>

              <CheckBox
                className="leading-[normal] text-left text-sm"
                inputClassName="border border-pink-600 border-solid h-[18px] mr-[5px] w-[18px]"
                name="imatobaccouser"
                id="imatobaccouser"
                label="I’m a Tobacco User"
                size="xs"
                onChange={applicantData}
              ></CheckBox>
            </div>

          </div>
          {/* Add me  */}


          {/* popup Add Spouse*/}


          {showPopupSpouse && (
            <div className="popup-overlay bg-white-A700 border border-pink-600 border-solid flex flex-col font-roboto items-center justify-end p-11 md:px-10 sm:px-5 rounded-[19px] shadow-bs3 w-full">
              <div className="deleteSpousePopUp" onClick={canCellSpouse}>X</div>
              <div className="popup-container w-[100%]">
                {/*  */}


                <div className="flex flex-col gap-[30px] items-start justify-start min-w-full w-auto sm:w-full">
                  <div className="flex flex-row gap-1.5 items-center justify-start w-[30%] md:w-full">
                    <div className="bg-gray-100 text-[black] flex flex-row items-start justify-end min-h-[40px] min-w-[40px] p-[10px] rounded-[50%]">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        className="h-6 w-6 ml-auto cursor-pointer"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M5 12h14m-7 7v-14"
                        />
                      </svg>
                    </div>

                    <Text
                      className="text-[25px] sm:text-[31px] md:text-[33px] text-blue-700 font-bold"
                      size="txtRobotoRomanSemiBold35"
                    >
                      Spouse
                    </Text>
                  </div>
                  <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                    <Text
                      className="text-[15px] text-gray-500_01"
                      size="txtRobotoRomanRegular15"
                    >
                      Name
                    </Text>
                    <div className="relative bg-gray-200 flex items-center rounded-md w-[100%] sm:w-full p-3">
                      <input
                        type="text"
                        placeholder="Name"
                        className="bg-transparent w-full outline-none focus:outline-none border-none"
                      />

                    </div>

                  </div>
                  <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                    <Text
                      className="text-[15px] text-gray-500_01"
                      size="txtRobotoRomanRegular15"
                    >
                      Date of Birth
                    </Text>
                    <div className="relative bg-gray-200 flex items-center rounded-md w-[100%] sm:w-full p-3">
                      <input
                        type="date"
                        placeholder="Date of Birth"
                        className="bg-transparent w-full outline-none focus:outline-none border-none"
                      />
                    </div>

                  </div>
                  <div className="flex flex-col gap-[13px] items-start justify-start w-[31%] md:w-full">
                    <Text
                      className="text-[15px] text-gray-500_01"
                      size="txtRobotoRomanRegular15"
                    >
                      Gender
                    </Text>
                    <RadioGroup
                      className="flex flex-col w-full"
                      name="radiogroupmale2"
                    >
                      <Radio
                        value="Male"
                        className="leading-[normal] sm:pr-5 text-blue_gray-900_02 text-left text-sm"
                        inputClassName="bg-white-A700  border border-blue-900 border-solid h-4 mr-[5px] rounded-[13px] w-4"
                        checked={true}
                        aria-checked={true}
                        name="radiogroupmale2"
                        label="Male"
                        id="Male"
                      ></Radio>
                      <Radio
                        value="Female"
                        className="leading-[normal] mt-4 sm:pr-5 text-blue_gray-900_02 text-left text-sm"
                        inputClassName="bg-white-A700 border border-blue-900 border-solid h-4 mr-[5px] rounded-[13px] w-4"
                        checked={false}
                        name="radiogroupmale2"
                        label="Female"
                        id="Female"
                      ></Radio>
                    </RadioGroup>
                  </div>
                  <CheckBox
                    className="leading-[normal] text-left text-sm"
                    inputClassName="border border-pink-600 border-solid h-[18px] mr-[5px] w-[18px]"
                    name="imatobaccouser"
                    id="imatobaccouser"
                    label="She is a Tobacco User"
                    size="xs"
                  ></CheckBox>
                </div>

              </div>
              {/* Add Spouse */}
            </div>
          )}
          {/* Popup End Add Spouse*/}




          {/* popup Add Dependent*/}


          {popups.map((popupKey) => (
            <div key={popupKey} className="popup-overlay bg-white-A700 border border-pink-600 border-solid flex flex-col font-roboto items-center justify-end p-11 md:px-10 sm:px-5 rounded-[19px] shadow-bs3 w-full">
              <div className="deleteSpousePopUp" onClick={() => canCellDependents(popupKey)}>
                X</div>

              {/* Add Spouse */}
              <div className="popup-container w-[100%]">
                {/*  */}


                <div className="flex flex-col gap-[30px] items-start justify-start min-w-full w-auto sm:w-full">
                  <div className="flex flex-row gap-1.5 items-center justify-start w-[30%] md:w-full">
                    <div className="bg-gray-100 text-[black] flex flex-row items-start justify-end min-h-[40px] min-w-[40px] p-[10px] rounded-[50%]">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        className="h-6 w-6 ml-auto cursor-pointer"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M5 12h14m-7 7v-14"
                        />
                      </svg>
                    </div>

                    <Text
                      className="text-[25px] sm:text-[31px] md:text-[33px] text-blue-700 font-bold"
                      size="txtRobotoRomanSemiBold35"
                    >
                      Dependent
                    </Text>
                  </div>
                  <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                    <Text
                      className="text-[15px] text-gray-500_01"
                      size="txtRobotoRomanRegular15"
                    >
                      Name
                    </Text>
                    <div className="relative bg-gray-200 flex items-center rounded-md w-[100%] sm:w-full p-3">
                      <input
                        type="text"
                        placeholder="Name"
                        className="bg-transparent w-full outline-none focus:outline-none border-none"
                      />

                    </div>

                  </div>
                  <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                    <Text
                      className="text-[15px] text-gray-500_01"
                      size="txtRobotoRomanRegular15"
                    >
                      Date of Birth
                    </Text>
                    <div className="relative bg-gray-200 flex items-center rounded-md w-[100%] sm:w-full p-3">
                      <input
                        type="date"
                        placeholder="Date of Birth"
                        className="bg-transparent w-full outline-none focus:outline-none border-none"
                      />
                    </div>

                  </div>
                  <div className="flex flex-col gap-[13px] items-start justify-start w-[31%] md:w-full">
                    <Text
                      className="text-[15px] text-gray-500_01"
                      size="txtRobotoRomanRegular15"
                    >
                      Gender
                    </Text>
                    <RadioGroup
                      className="flex flex-col w-full"
                      name="radiogroupmale2"
                    >
                      <Radio
                        value="Male"
                        className="leading-[normal] sm:pr-5 text-blue_gray-900_02 text-left text-sm"
                        inputClassName="bg-white-A700  border border-blue-900 border-solid h-4 mr-[5px] rounded-[13px] w-4"
                        checked={true}
                        aria-checked={true}
                        name="radiogroupmale2"
                        label="Male"
                        id="Male"
                      ></Radio>
                      <Radio
                        value="Female"
                        className="leading-[normal] mt-4 sm:pr-5 text-blue_gray-900_02 text-left text-sm"
                        inputClassName="bg-white-A700 border border-blue-900 border-solid h-4 mr-[5px] rounded-[13px] w-4"
                        checked={false}
                        name="radiogroupmale2"
                        label="Female"
                        id="Female"
                      ></Radio>
                    </RadioGroup>
                  </div>
                  <CheckBox
                    className="leading-[normal] text-left text-sm"
                    inputClassName="border border-pink-600 border-solid h-[18px] mr-[5px] w-[18px]"
                    name="imatobaccouser"
                    id="imatobaccouser"
                    label="She is a Tobacco User"
                    size="xs"
                  ></CheckBox>
                </div>
                {/* <button onClick={handleSubmit} className="bg-gray-200 border border-blue-900 border-solid flex flex-row font-roboto gap-[22px] h-[65px] md:h-auto items-center justify-start min-w-full md:px-10 sm:px-5 px-[52px] py-[21px] rounded-[12px] shadow-bs3 md:w-full" type="button">
                  <div className="flex flex-row items-start justify-center w-[6%]">
                  </div>
                  <Text
                    className="text-base text-[#535353] w-auto font-bold"
                    size="txtRobotoRomanSemiBold20Bluegray70001"
                  >
                    Submit
                  </Text>
                </button> */}
              </div>
            </div>
          ))}
          {/* Popup End Add Dependent*/}

          {/* popup Add Dependent*/}



          {/* Popup End Add Dependent*/}

          <button onClick={handleSpouse} className="bg-gray-200 border border-blue-900 border-solid flex flex-row font-roboto gap-[22px] h-[65px] md:h-auto items-center justify-start min-w-full md:px-10 sm:px-5 px-[52px] py-[21px] rounded-[12px] shadow-bs3 md:w-full" type="button">
            <div className="flex flex-row items-start justify-center w-[6%]">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="h-6 w-6 ml-auto cursor-pointer"

              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 12h14m-7 7v-14"
                />
              </svg>
            </div>
            <Text
              className="text-base text-[#535353] w-auto font-bold"
              size="txtRobotoRomanSemiBold20Bluegray70001"
            >
              ADD SPOUSE
            </Text>
          </button>
          <button onClick={handleDependents} className="bg-gray-200 border border-blue-900 border-solid flex flex-row font-roboto gap-[22px] h-[65px] md:h-auto items-center justify-start min-w-full md:px-10 sm:px-5 px-[52px] py-[21px] rounded-[12px] shadow-bs3 md:w-full" type="button">
            <div className="flex flex-row items-start justify-center w-[6%]">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                className="h-6 w-6 ml-auto cursor-pointer"

              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M5 12h14m-7 7v-14"
                />
              </svg>
            </div>
            <Text
              className="text-base text-[#535353] w-auto font-bold"
              size="txtRobotoRomanSemiBold20Bluegray70001"
            >
              ADD DEPENDENT
            </Text>
          </button>
          <Button
            className="cursor-pointer font-bold font-montserrat h-[65px] min-w-full py-7 text-[15.26px] text-center tracking-[0.28px]"
            shape="round"
            color="pink_600"
            variant="fill"
            onClick={() => {
              // nevigate("/form-two")
              nevigate("/form-two", { state: applicant });
            }}
          >
            Continue to Household Size
          </Button>
          <Button
            className="cursor-pointer  font-bold mb-12 font-montserrat h-[65px] min-w-full py-[25px] text-[15.26px] text-center tracking-[0.28px]"
            shape="round"
            color="gray_800"
            variant="fill"
            style={{ backgroundColor: '#BBB' }}
            onClick={() => {
              nevigate("/")
            }}
          >
            Go Back
          </Button>
        </div>


      </div>


      {/* <div className="bg-white-A700 flex flex-col font-montserrat items-center justify-end mx-auto pt-1.5 w-full">


        <div className="h-1 md:h-[119px] max-w-[1504px] mt-[33px] mx-auto md:px-5 relative w-[85%] md:w-full">
          <Img
            className="absolute h-1.5 inset-x-[0] mx-auto top-[41%] w-[96%]"
            src="images/img_frame377.svg"
            alt="frame377"
          />
          <Img
            className="absolute h-[66px] inset-[0] justify-center m-auto rounded-[50%] w-[66px]"
            src="images/img_ellipse9.png"
            alt="ellipseNine"
          />
        </div>


        <div className="flex flex-col items-center justify-start mt-[51px] md:px-5 w-[21%] md:w-full">
          <div className="flex flex-col gap-[11px] items-center justify-start w-full">
            <Text
              className="sm:text-[21px] md:text-[23px] text-center text-gray-800 text-lg tracking-[-0.55px]"
              size="txtMontserratSemiBold25"
            >
              Let’s add members to your plan.
            </Text>
            <Text
              className="leading-[143.50%] sm:text-[21px] md:text-[23px] text-center text-gray-600 text-lg tracking-[-0.55px] w-[97%] sm:w-full"
              size="txtMontserratMedium25Gray600"
            >
              Who are you buying health insurance for today?
            </Text>
          </div>
        </div>


        <div className="flex flex-col gap-11 items-center justify-start mt-[90px] md:px-5 w-[32%] md:w-full">
          <div className="bg-white-A700 border border-pink-600 border-solid flex flex-col font-roboto items-center justify-end p-11 md:px-10 sm:px-5 rounded-[19px] shadow-bs3 w-full">
            <div className="flex flex-col gap-[30px] items-start justify-start min-w-full w-auto sm:w-full">
              <div className="flex flex-row gap-1.5 items-center justify-start w-[30%] md:w-full">
                <div className="bg-gray-100_03 flex flex-row items-start justify-end min-h-[40px] min-w-[40px] p-[11px] rounded-[50%]">
                  <Img
                    className="h-[19px] my-0"
                    src="images/img_lock_blue_900.svg"
                    alt="lock"
                  />
                  <Text
                    className="text-[15px] text-blue-900"
                    size="txtRobotoRomanSemiBold15Blue900"
                  >
                    +
                  </Text>
                </div>
                <Text
                  className="text-[22px] sm:text-[31px] md:text-[33px] text-blue-900"
                  size="txtRobotoRomanSemiBold35"
                >
                  ME
                </Text>
              </div>
              <div className="flex flex-col gap-[15px] items-start justify-start w-full">
                <Text
                  className="text-[15px] text-gray-500_01"
                  size="txtRobotoRomanRegular15"
                >
                  Date of Birth
                </Text>
                <div className="bg-gray-200 flex flex-col items-start justify-start rounded-md w-auto sm:w-full">
                  <Img
                    className="h-[22px] md:h-auto object-cover w-[22px]"
                    src="images/img_calendar.png"
                    alt="calendar"
                  />
                </div>
              </div>
              <div className="flex flex-col gap-[13px] items-start justify-start w-[31%] md:w-full">
                <Text
                  className="text-[15px] text-gray-500_01"
                  size="txtRobotoRomanRegular15"
                >
                  Gender
                </Text>
                <RadioGroup
                  className="flex flex-col w-full"
                  name="radiogroupmale2"
                >
                  <Radio
                    value="Male"
                    className="leading-[normal] sm:pr-5 text-blue_gray-900_02 text-left text-sm"
                    inputClassName="bg-white-A700 border border-blue-900 border-solid h-4 mr-[5px] rounded-[13px] w-4"
                    checked={false}
                    name="radiogroupmale2"
                    label="Male"
                    id="Male"
                  ></Radio>
                  <Radio
                    value="Female"
                    className="leading-[normal] mt-4 sm:pr-5 text-blue_gray-900_02 text-left text-sm"
                    inputClassName="bg-pink-600 border-[5px] border-blue-900 border-solid h-4 mr-[5px] rounded-[13px] w-4"
                    checked={false}
                    name="radiogroupmale2"
                    label="Female"
                    id="Female"
                  ></Radio>
                </RadioGroup>
              </div>
              <CheckBox
                className="leading-[normal] text-left text-sm"
                inputClassName="border border-pink-600 border-solid h-[18px] mr-[5px] w-[18px]"
                name="imatobaccouser"
                id="imatobaccouser"
                label="I’m a Tobacco User"
                size="xs"
              ></CheckBox>
            </div>
          </div>
          <div className="bg-gray-200 border border-blue-900 border-solid flex flex-row font-roboto gap-[22px] h-[65px] md:h-auto items-center justify-start min-w-full md:px-10 sm:px-5 px-[52px] py-[21px] rounded-[12px] shadow-bs3 md:w-full">
            <div className="flex flex-row items-start justify-center w-[6%]">
              <Img
                className="h-[17px] mt-[3px]"
                src="images/img_lock_blue_gray_700_01.svg"
                alt="lock_One"
              />
              <Text
                className="text-[15px] text-blue_gray-700_01"
                size="txtRobotoRomanSemiBold15Bluegray70001"
              >
                +
              </Text>
            </div>
            <Text
              className="text-base text-blue_gray-700_01 w-auto"
              size="txtRobotoRomanSemiBold20Bluegray70001"
            >
              ADD SPOUSE
            </Text>
          </div>
          <div className="bg-gray-200 border border-blue-900 border-solid flex flex-row font-roboto gap-[22px] h-[65px] md:h-auto items-center justify-start min-w-full md:px-10 sm:px-5 px-[52px] py-[21px] rounded-[12px] shadow-bs3 md:w-full">
            <div className="flex flex-row items-start justify-center w-[6%]">
              <Img
                className="h-[17px] mt-[3px]"
                src="images/img_lock_blue_gray_700_01.svg"
                alt="lock_Two"
              />
              <Text
                className="text-[15px] text-blue_gray-700_01"
                size="txtRobotoRomanSemiBold15Bluegray70001"
              >
                +
              </Text>
            </div>
            <Text
              className="text-base text-blue_gray-700_01 w-auto"
              size="txtRobotoRomanSemiBold20Bluegray70001"
            >
              ADD DEPENDENT
            </Text>
          </div>
          <Button
            className="cursor-pointer font-bold font-montserrat h-[65px] min-w-full py-7 text-[15.26px] text-center tracking-[0.28px]"
            shape="round"
            color="pink_600"
            variant="fill"
          >
            Continue to Household Size
          </Button>
          <Button
            className="cursor-pointer font-bold font-montserrat h-[65px] min-w-full py-[25px] text-[15.26px] text-center tracking-[0.28px]"
            shape="round"
            color="gray_400_02"
            variant="fill"
          >
            Go Back
          </Button>
        </div>


      </div>  */}


      <Footer />
    </>
  );
};

export default FormOnePage;


