import React from "react";
import HorizontalLine from 'components/HorizontalLine/index'
import { Button, Img, Line, RatingBar, Text } from "components";
import Footer from "components/Footer";
import Header from "components/Header";
import "./formthree.css"
import { useState } from 'react';
import { Carousel, Image } from 'react-bootstrap';
import cardimg from '../FormThree/cardimg.webp'
import fivestar from '../FormThree/5star.webp'
// import ExampleCarouselImage from 'components/ExampleCarouselImage';
import { useNavigate, useLocation } from "react-router-dom";



const FormThreePage = () => {
  const nevigate = useNavigate()
  const location = useLocation();
  // Access the state object from the location
  const { state } = location;
  // console.log(state)
  console.log(state.results)
  const results = state.results

  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex, e) => {
    setIndex(selectedIndex,e);
  };
  return (
    <>
      <div className="bg-white-A700 flex flex-col font-montserrat items-center justify-end mx-auto pt-1.5 w-full">
        <div className="flex flex-col items-center justify-start max-w-[1736px] mx-auto md:px-5 w-full">
          <Header className="flex flex-col items-center justify-center w-full" />
          <HorizontalLine />
          {/* <div className="flex md:flex-col flex-row md:gap-10 gap-32 h-[88px] items-start justify-between mt-5 w-[70%] md:w-full">
            <Button
              className="border-b border-blue-900 border-solid cursor-pointer font-semibold h-[50px] sm:text-[21px] md:text-[23px] text-center text-lg tracking-[-0.55px] w-[400px]"
              shape="square"
              color="blue_900_19"
              size="xl"
              variant="fill"
            >
              Recommended Plans
            </Button>
            <Button
              className="cursor-pointer font-semibold h-[50px] sm:text-[21px] md:text-[23px] text-center text-lg tracking-[-0.55px] w-[327px]"
              shape="square"
              color="gray_300"
              size="xl"
              variant="outline"
            >
              All Plans
            </Button>
            <Button
              className="cursor-pointer font-semibold h-[50px] sm:text-[21px] md:text-[23px] text-center text-lg tracking-[-0.55px] w-[327px]"
              shape="square"
              color="gray_300"
              size="xl"
              variant="outline"
            >
              Lowest Plans
            </Button>
          </div> */}


          <div className="container">
            <div className="threeButtons">
              <div className="row d-flex justify-content-between gap-4">
                <div className="col-lg-3">
                  <button>Recommended Plans</button>
                </div>
                <div className="col-lg-3">
                  <button>All Plans</button>
                </div>
                <div className="col-lg-3">
                  <button>Lowest Plans</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <br />
        <br />

        {/* <div className="container">
          <div className="card-data">
            <div className="row">
              <div className="col-lg-5  first">
                <img src={cardimg} alt="" />
                <h1>Minimum Coverage HMO - HMO</h1>
              </div>
              <div className="col-lg-3 second">
                <p>Premium</p>
                <h1>{results[0].Premium}</h1>
              </div>
              <div className="col-lg-4 third">
                <p>Health deductible</p>
                <h1>{results[0]["Medical & Drug Deductible"]}</h1>
              </div>
            </div>
            <div className="row">
              <div className="col-lg-4 forth">
                <img src={fivestar} alt="" />
                <p >CATASTROPHIC</p>
              </div>
              <div className="col-lg-4 mt-4 fifth">
                <div className="d-flex">
                  <p>Your estimated all-in</p>
                  <h1>$9,450</h1>
                </div>
                <div className="d-flex ">
                  <p>Out-of-pocket max</p>
                  <h1>{results[0]["Medical & Drug Out-of-Pocket Maximum"]}</h1>
                </div>
              </div>
              <div className="col-lg-4 mt-4 sixth">
                <div className="d-flex gap-5">
                  <p>Doctor visits</p>
                  <h1> {results[0]["Specialist Visit"]}</h1>
                </div>
                <div className="d-flex gap-5">
                  <p>Generic drugs</p>
                  <h1>{results[0]["Generic Drugs"]}</h1>
                </div>
              </div>
            </div>
            <div className="row mt-3 ps-5 d-flex flex-colum justify-content-center">
              <div className="col-lg-5 btn1">
                <button>Plan Details</button>
              </div>
              <div className="col-lg-5 btn2">
                <button>Enroll Now</button>
              </div>
            </div>
          </div>
        </div> */}

        <div className="container mt-5">
          <Carousel activeIndex={index} onSelect={handleSelect}>
            {results.map((result, idx) => (
              <Carousel.Item key={idx}>
                <div className="card-data">
                  <div className="row">
                    <div className="col-lg-5 first">
                      {/* Use the result data dynamically */}
                      <img src={cardimg} alt="" />
                      <h1>{result["Plan Name"]}</h1>
                    </div>
                    <div className="col-lg-3 second">
                      <p>Premium</p>
                      <h1>{result.Premium}</h1>
                    </div>
                    <div className="col-lg-4 third">
                      <p>Health deductible</p>
                      <h1>{result["Medical & Drug Deductible"]}</h1>
                    </div>
                  </div>
                  <div className="row">
                    <div className="col-lg-4 forth">
                      <img src={fivestar} alt="" />
                      <p>CATASTROPHIC</p>
                    </div>
                    <div className="col-lg-4 mt-4 fifth">
                      <div className="d-flex">
                        <p>Your estimated all-in</p>
                        <h1>$9,450</h1>
                      </div>
                      <div className="d-flex ">
                        <p>Out-of-pocket max</p>
                        <h1>{result["Medical & Drug Out-of-Pocket Maximum"]}</h1>
                      </div>
                    </div>
                    <div className="col-lg-4 mt-4 sixth">
                      <div className="d-flex gap-5">
                        <p>Doctor visits</p>
                        <h1>{result["Specialist Visit"]}</h1>
                      </div>
                      <div className="d-flex gap-5">
                        <p>Generic drugs</p>
                        <h1>{result["Generic Drugs"]}</h1>
                      </div>
                    </div>
                  </div>
                  <div className="row mt-3 ps-5 d-flex flex-colum justify-content-center">
                    <div className="col-lg-5 btn1">
                      <button>Plan Details</button>
                    </div>
                    <div className="col-lg-5 btn2">
                      <button>Enroll Now</button>
                    </div>
                  </div>
                </div>
              </Carousel.Item>
            ))}
          </Carousel>
        </div>




        <Footer className="flex items-center justify-center mt-[168px] md:px-5 w-full" />
      </div>
    </>
  );
};

export default FormThreePage;
