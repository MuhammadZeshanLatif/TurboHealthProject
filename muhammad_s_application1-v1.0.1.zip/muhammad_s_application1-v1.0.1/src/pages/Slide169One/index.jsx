import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button, Img, Input, List, Text } from "components";
import Footer from "components/Footer";
import Header from "components/Header";
import Slide169OneNaked from "components/Slide169OneNaked";
import Slide169OneShadow from "components/Slide169OneShadow";
import FormOnePage from "../FormOne/index"
// import FormOnePage from "pages/FormOne/index.jsx"



const Slide169OnePage = () => {
 
 const navigate = useNavigate();
  const [zipCode, setZipCode] = useState();
  const [catigory, setCatigory] = useState("Medicare");
  const [activeButton, setActiveButton] = useState('medicare'); // Default active button
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState();
  const [selectedItemIndex, setSelectedItemIndex] = useState(null);
  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [nzc, setnzc]=useState();
  const handleSelectedItemIndex = (index) => {
    setSelectedItemIndex(index);
  };
  //  const [activeButton, setActiveButton] = useState(1); // Initial active button (1 for Medicare, 2 for Individuals & family, 3 for Dental & Vision)
  // const [zipCode, setZipCode] = useState('');

  // const handleButtonClick = (buttonId) => {
  //   setActiveButton(buttonId);
  // };


  const changePage = (newPage) => {
    // Use window.location.href to change the page
    window.location.href = newPage;
  };
  
  const getZipCode = (e) => {
    setZipCode(e)
    console.log(catigory)
  }
  
  const sendZipCode = async () => {
   
    const catigorySend = {
      "catigory": catigory,
      "zipCode": zipCode
      //77494
    }

    if (catigory == "Dental & Vision") {
      catigorySend["catigory"] = "Dental"

    }
    else if (catigory == "Individuals & Family") {
      catigorySend["catigory"] = "Individuals"
    } else {
      catigorySend["catigory"] = catigory
    }
    console.log(catigorySend);


    if (zipCode == "") { alert("Enter ZipCode") }
    else {
      
      setData("Loading....");
      console.log(zipCode);

      try {
        // ... your fetch logic
  
        const response = await fetch('http://localhost:3000/countryCode', {
          method: 'POST',
          body: JSON.stringify(catigorySend),
          headers: {
            'Content-Type': 'application/json'
          }
        });
  
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
  
        const rs = await response.json();
  
        if (!rs.stateCountyList || !rs.stateCountyList.state || !rs.stateCountyList.countyOptions || rs.stateCountyList.countyOptions.length === 0) {
          throw new Error('Data not found or has unexpected format');
        }
  
        console.log(rs.stateCountyList.state);
        const rsData = rs.stateCountyList.countyOptions;
        console.log("Hell")
        const countryData = rsData.map((item, index) => (
          <div key={index} className="rounded border p-3 mb-2 d-flex justify-content-between animate__animated animate__backInUp row">
            <div className="flex justify-between items-center p-2 border-b">
              <div className="mr-5 text-[#ffff]">{item.name}</div>
              <button
                className="bg-[#ffffff] text-[#000000] px-5 py-1 border-[#d3134a] mx-5 rounded transition duration-300 hover:bg-[#d3134a] hover:text-white"
                onClick={() => {
                   getDataAll(index);
                   closePopup();
                  // window.open('src/pages/FormOne/');
                 
                }}
              >
                Select
              </button>
            </div>
          </div>
        ));
  
        if (countryData.length === 0) {
          setData('No data found. Please try another zip code.');
        } else {
          setData(countryData);
        }
      } catch (error) {
        console.error('Error fetching data:', error.message);
        setData('Error: Unable to fetch data');
      }


    }
  }
  const slide169OneShadowPropList = [
    {},
    {
      article: "video",
      inthisarticle:
        "Dashboard is the hub for millions of businesses to take action. We’ve launched dozens of new features in the Dashboard...",
      guidefordesigniOne: "New Dashboard features to save you time",
      userimage: "images/img_rectangle4_201x360.png",
    },
    {
      article: "Case study",
      inthisarticle:
        "The health platform boosted acceptance rates and expanded global coverage by switching to Dlex",
      guidefordesigniOne:
        "Noom sees an 8% increase in authorization rates with Dlex",
      userimage: "images/img_rectangle4_201x360.png",
    },
  ];




  const openPopup = () => {
    setIsPopupOpen(true);
  };

  const closePopup = () => {
    setIsPopupOpen(false);
  };
  const handleButtonClick = async (buttonType) => {
    setActiveButton(buttonType);
  };
  const getDataAll = async (buttonType) => {
    setActiveButton(buttonType);
    const catigorySend = {
      "catigory": catigory,
      "zipCode": zipCode,
      "tindex": buttonType
    }
    navigate("/form-one", { state: catigorySend });
    setnzc(catigorySend);
    // console.log('Clicked on item with index:', buttonType);
    // try {
    //   const response = await fetch('http://localhost:3000/getData', {
    //     method: 'POST',
    //     body: JSON.stringify(catigorySend),
    //     headers: {
    //       'Content-Type': 'application/json'
    //     }
    //   });

    //   if (!response.ok) {
    //     throw new Error(`HTTP error! Status: ${response.status}`);
    //   }

    //   const rs = await response.json();
    //   console.log(rs);

    // } catch (error) {
    //   console.error('Error fetching data:', error.message);
    //   // setData('Error: Unable to fetch data');
    // }
  };


  return (
    <>
      {/* header Start */}
      <Header className="flex flex-col items-center justify-center md:px-5 w-full" />
      {/* Header End */}





      {/* Hero Section Start */}
      <div className="flex flex-col p-0 md:px-5 relative w-full">
        <div className="sm:h-[1063px] md:h-[810px] h-[950px] mx-auto w-full">
          <div className="absolute block flex-col inset-[0] justify-center m-auto w-full">
            <div className=" mx-auto w-full">
              <Img
                className="block h-[650px]  items-start m-auto object-cover rounded-[-4px] w-[100%]"
                src="images/img_image1.png"
                alt="imageOne"
              />
              <div className="absolute flex flex-col h-[600px] items-start justify-center left-[111px] ml-11 my-auto overflow-visible text-colors top-[0] w-[40%]">
                <Text
                  className="inline mt-[159px] static sm:text-4xl md:text-[15px] text-[25px] text-center text-gray-800 tracking-[0.20px]"
                  size="txtMontserratBold40"
                >
                  Your One-stop Shop for Health Insurance
                </Text>
                <Text
                  className="mt-11 sm:text-[21px] md:text-[23px] text-[15px] text-gray-800 tracking-[0.20px]"
                  size="txtMontserratMedium25"
                >
                  Select the insurance you need, provide your ZIP, and see
                  plans fast!
                </Text>
                <div className="flex flex-col items-start justify-start mb-[0] md:ml-[0] ml-[3px] mr-[0] mt-[27px] w-[90%] md:w-full">
                  <div className="flex sm:flex-col flex-row gap-1.5 items-center justify-start w-full md:w-[80%] lg:w-[60%] xl:w-[40%] mx-auto">
                    <Button
                      className={`${activeButton === 'medicare'
                        ? '!text-pink-600 border-pink-600 border-solid border-t-2 font-bold'
                        : 'font-medium'
                        } capitalize cursor-pointer min-w-[90px] md:min-w-[120px] lg:min-w-[160px] rounded-tl-[10px] rounded-tr-[10px] text-[12.38px] text-center tracking-[0.26px]`}
                      color="white_A700"
                      size="lg"
                      variant="fill"
                      onClick={() => {
                        handleButtonClick('medicare');
                        setCatigory('Medicare')
                      }}
                    >
                      Medicare
                    </Button>
                    
                    <Button
                      className={`${activeButton === 'individuals'
                        ? '!text-pink-600 border-pink-600 border-solid border-t-2 font-bold'
                        : 'font-medium'
                        } capitalize cursor-pointer min-w-[160px] md:min-w-[200px] lg:min-w-[240px] rounded-tl-[10px] rounded-tr-[10px] text-[12.38px] text-center tracking-[0.26px]`}
                      color="white_A700"
                      size="lg"
                      variant="fill"
                      onClick={() => {
                        handleButtonClick('individuals');
                        setCatigory("Individuals & Family")
                      }}
                    >
                      Individuals & Family
                    </Button>
                    <Button
                      className={`${activeButton === 'dental'
                        ? '!text-pink-600 border-pink-600 border-solid border-t-2 font-bold'
                        : 'font-medium'
                        } capitalize cursor-pointer min-w-[154px] md:min-w-[180px] lg:min-w-[220px] rounded-tl-[10px] rounded-tr-[10px] text-[12.38px] text-center tracking-[0.26px]`}
                      color="white_A700"
                      size="lg"
                      variant="fill"
                      onClick={() => {
                        handleButtonClick('dental');
                        setCatigory("Dental & Vision")
                      }}
                    >
                      Dental & Vision
                    </Button>
                  </div>
                  <div className="bg-white-A700 flex flex-col h-[250px] items-start justify-start p-[29px] sm:px-5 rounded-bl-[10px] rounded-br-[10px] rounded-tr-[10px] shadow-bs1 w-full">
                    <div className="flex flex-col items-start justify-start mb-[22px] mt-4 w-[91%] md:w-full">
                      <Text
                        className="capitalize text-[12.38px] text-center text-gray-800 tracking-[0.26px]"
                        size="txtMontserratBold1838"
                      >
                        Compare {catigory} plans and enroll online. easy. fast
                      </Text>
                      <Text
                        className="capitalize mt-7 text-[12.38px] text-center text-gray-800 tracking-[0.26px]"
                        size="txtMontserratRegular1838"
                      >
                        Enter your zIP code
                      </Text>
                      <div className="flex sm:flex-col flex-row gap-3.5  items-center justify-between mt-5 w-full">
                        <Input
                          onChange={getZipCode}
                          placeholder=""
                          className="p-2 w-full"
                          wrapClassName="border border-gray-800 border-solid flex sm:flex-1 h-[44px] rounded-[10px] w-[300px] sm:w-full"
                        ></Input>
                        <Button
                          onClick={() => {
                            sendZipCode();
                            openPopup();
                          }}
                          className="!bg-colors1 cursor-pointer font-bold h-[44px] min-w-[200px] rounded-[10px] text-center text-sm text-white-A700 tracking-[0.20px]"
                          shape="round"
                          color="pink_600"
                          size="lg"
                          variant="fill"
                        >
                          Find medicare plans
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex sm:flex-col flex-row gap-4 items-center justify-start md:ml-[0] ml-[3px] mt-16 w-[100%] md:w-full">
                  <div className="bg-white-A700 flex flex-col h-[40px] items-center justify-end p-0.5 rounded-[3px] w-[20%] sm:w-full">
                    <Img
                      className="h-[50px] md:h-auto object-cover overflow-visible w-[100%]"
                      src="images/img_image214.png"
                      alt="image214"
                    />
                  </div>
                  <div className="bg-white-A700 flex flex-col h-[40px] items-center justify-end p-0.5 rounded-[3px] w-[32%] sm:w-full">
                    <Img
                      className="h-[40px] md:h-auto object-cover overflow-visible w-[40%]"
                      src="images/img_image212.png"
                      alt="image212"
                    />
                  </div>
                  <div className="bg-white-A700 flex flex-col h-[40px] items-center justify-end p-0.5 rounded-[3px] w-[20%] sm:w-full">
                    <Img
                      className="h-[50px] md:h-auto object-cover overflow-visible w-[100%]"
                      src="images/img_image215.png"
                      alt="image215"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-blue-900 h-[159px] mt-[-27px] mx-auto w-full z-[1] flex items-center justify-center">
              <div className="flex justify-evenly w-[60%] mt-[40px]">
                <svg xmlns="http://www.w3.org/2000/svg" width="103" height="35" viewBox="0 0 103 35" fill="none">
                  <g clip-path="url(#clip0_3_381)">
                    <path d="M23.2554 32.4249L29.4193 32.5526C27.2949 31.8183 25.2349 30.9244 23.2554 29.8709V32.4249ZM32.5415 31.5789V32.4249L29.4193 32.5526C35.2935 34.5479 40.6688 34.8192 44.6601 33.7019C41.4574 33.7338 37.2892 33.2868 32.5415 31.5789ZM98.3488 13.1901C100.908 13.1901 103 11.131 103 8.57697C103 6.02298 100.924 4.66617 98.3488 4.66617C95.7899 4.66617 93.6977 6.03894 93.6977 8.57697C93.6977 11.115 95.7738 13.1901 98.3488 13.1901ZM93.6816 32.4249H103V14.7864H93.6816V32.4249ZM81.8206 32.4249H91.1388V1.25021L81.8206 5.60796V32.4249ZM76.8315 13.3657C73.9024 10.4605 68.7202 10.6361 68.7202 10.6361C68.7202 10.6361 63.522 10.4605 60.609 13.3657C57.6799 16.2709 57.9052 18.777 57.9052 21.7619C57.9052 24.7469 57.6799 27.2371 60.609 30.1422C63.5381 33.0474 68.7202 32.8718 68.7202 32.8718C68.7202 32.8718 73.9185 33.0474 76.8315 30.1422C79.7606 27.2371 79.5352 24.7469 79.5352 21.7619C79.5192 18.761 79.7445 16.2549 76.8315 13.3657ZM70.4262 24.8427C70.4262 25.4173 70.1365 26.838 68.7042 26.838C67.2718 26.838 66.9821 25.4173 66.9821 24.8427V18.3939C66.9821 17.0051 68.157 16.654 68.7042 16.654C69.2513 16.654 70.4262 16.9892 70.4262 18.3939V24.8427ZM53.3346 13.3657C50.4056 10.4605 45.2234 10.6361 45.2234 10.6361C45.2234 10.6361 40.0412 10.4605 37.1121 13.3657C36.8063 13.669 36.5167 13.9882 36.2592 14.3235C30.1113 9.59857 24.5912 6.90091 19.8274 4.5704V1.26617L16.2063 2.95819C7.45135 -0.569511 1.88291 0.0530254 0.547129 2.97415C0.547129 2.97415 -3.46021 8.20983 10.4931 20.6605V32.4249H19.8113V27.8596C18.7653 27.1892 17.7192 26.4709 16.6892 25.6887C14.3073 23.9009 12.2795 22.2408 10.5092 20.6765V15.7281C12.6174 18.0746 15.4178 20.7404 19.1032 23.7573L19.8274 24.3319V19.5751C19.8274 18.4737 20.101 16.6699 21.5656 16.6699C23.0301 16.6699 23.2715 17.7713 23.2715 19.0643V26.838C26.1684 28.7854 29.2745 30.3657 32.5576 31.5629V16.5742C32.5576 13.5892 30.401 10.6042 26.0235 10.6042C23.4807 10.5882 21.1149 11.9131 19.8274 14.1V5.43237C26.5707 8.76852 33.3301 12.8549 35.9051 14.7385C34.2635 17.069 34.4084 19.2239 34.4084 21.7141C34.4084 24.699 34.1831 27.1892 37.1121 30.0943C40.0412 32.9995 45.2234 32.8239 45.2234 32.8239C45.2234 32.8239 50.4217 32.9995 53.3346 30.0943C56.2637 27.1892 56.0223 24.699 56.0223 21.7141C56.0223 18.761 56.2637 16.2549 53.3346 13.3657ZM10.4931 5.60796V15.7122C2.65541 7.01265 4.2326 3.58072 4.82807 3.08589C7.00072 1.26617 10.8632 1.80889 15.1924 3.4211L10.4931 5.60796ZM46.9454 24.8427C46.9454 25.4173 46.6557 26.838 45.2234 26.838C43.791 26.838 43.5013 25.4173 43.5013 24.8427V18.3939C43.5013 17.0051 44.6762 16.654 45.2234 16.654C45.7706 16.654 46.9454 16.9892 46.9454 18.3939V24.8427Z" fill="white" />
                  </g>
                  <defs>
                    <clipPath id="clip0_3_381">
                      <rect width="103" height="34" fill="white" transform="translate(0 0.5)" />
                    </clipPath>
                  </defs>
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" width="84" height="59" viewBox="0 0 84 59" fill="none">
                  <g clip-path="url(#clip0_3_384)">
                    <path d="M0.5 0.995265H13.1121V35.0099C13.1121 40.4047 15.5437 43.6154 17.5215 44.9519C15.4627 46.761 9.22148 48.3582 4.52031 44.4955C1.76445 42.2138 0.5 38.4163 0.5 34.8795V0.995265ZM79.2689 29.2729V25.6873H83.1272V13.1701H78.8961C77.2588 5.62399 70.5961 0.0173645 62.6365 0.0173645C53.4611 0.0173645 45.9879 7.5146 45.9879 16.7558V45.9624C48.5816 46.3372 51.7266 45.9135 54.3689 43.6806C57.141 41.3989 58.3893 37.6176 58.3893 34.0646V32.9726H64.6791V20.4555H58.3893V16.658C58.3893 11.0187 66.8514 11.0187 66.8514 16.658V29.224C66.8514 38.4489 74.3084 45.9624 83.5 45.9624V33.4942C81.1494 33.4942 79.2689 31.5873 79.2689 29.2729ZM31.5602 13.1375V31.5547C31.5602 34.0646 27.702 34.0646 27.702 31.5547V13.1375H15.252V34.7654C15.252 38.6444 16.5488 43.5665 22.5469 45.1801C28.5449 46.7773 31.9816 43.4524 31.9816 43.4524C31.6412 45.6364 29.6311 47.25 26.324 47.5759C23.8113 47.8367 20.6178 46.9892 19.0291 46.3047V57.7624C23.098 58.9848 27.3777 59.3596 31.6088 58.5284C39.2441 57.0453 44.0588 50.64 44.0588 42.0997V13.056H31.5602V13.1375Z" fill="white" />
                  </g>
                  <defs>
                    <clipPath id="clip0_3_384">
                      <rect width="83" height="59" fill="white" transform="translate(0.5)" />
                    </clipPath>
                  </defs>
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" width="102" height="75" viewBox="0 0 102 75" fill="none">
                  <g clip-path="url(#clip0_3_387)">
                    <path d="M102 0.145782C89.1225 8.82829 87.7519 15.1296 86.6362 17.0572C85.5684 19.0335 84.7716 26.825 82.9228 30.5993C81.0581 34.4222 74.2847 37.4352 72.3881 38.6987C70.5234 39.9622 67.8778 44.8704 65.7103 49.0983C48.4819 48.3855 39.0309 55.3834 24.4003 64.2603C29.0859 62.689 31.3012 61.5551 31.3012 61.5551C46.3144 55.7235 53.5022 50.4914 76.1016 53.5853C76.2769 53.5853 76.4044 53.6825 76.5478 53.7149C77.1694 54.0713 77.3925 54.8326 77.0419 55.4644L68.4516 70.9827C68.0531 71.7441 67.2084 72.149 66.3637 71.9708C46.155 68.1155 30.2016 74.7732 15.5391 74.9838C3.84094 75.162 0 69.5572 0 69.298C0 69.1199 0.095625 69.0227 0.270938 69.0227C0.270938 69.0227 6.375 69.0227 16.7025 66.5443C28.4325 43.8175 38.8875 35.8639 50.2669 35.8639C50.2669 35.8639 61.6941 35.8639 64.7062 45.8909C68.34 39.46 69.2166 37.9212 69.2166 37.9212C70.0612 36.3985 74.7947 25.4158 82.9866 15.0162C91.1944 4.64902 97.3941 2.07343 102 0.145782Z" fill="white" />
                  </g>
                  <defs>
                    <clipPath id="clip0_3_387">
                      <rect width="102" height="75" fill="white" />
                    </clipPath>
                  </defs>
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" width="103" height="43" viewBox="0 0 103 43" fill="none">
                  <g clip-path="url(#clip0_3_390)">
                    <path d="M26.5555 3.79318L19.5869 5.25682L19.5547 27.9114C19.5547 32.0955 22.7413 34.8 26.9739 34.8C29.3236 34.8 31.0457 34.3705 31.9952 33.8614V28.4841C31.0778 28.85 26.5716 30.1546 26.5716 25.9864V15.9318H31.9952V9.91818H26.5716L26.5555 3.79318ZM40.895 12.0023L40.4605 9.91818H34.2805V34.2909H41.41V17.8886C43.0999 15.6932 45.9485 16.1227 46.8658 16.4091V9.91818C45.9002 9.58409 42.5688 8.96364 40.895 12.0023ZM55.7496 0.5L48.5717 2.01136V7.77045L55.7496 6.25909V0.5ZM7.2269 17.0932C7.2269 15.9955 8.16034 15.5659 9.65706 15.55C11.8297 15.55 14.5978 16.2023 16.7705 17.3636V10.7136C14.4047 9.79091 12.0389 9.425 9.67315 9.425C3.8794 9.425 0.0168991 12.4159 0.0168991 17.4114C0.0168991 25.2386 10.8802 23.9659 10.8802 27.3386C10.8802 28.6432 9.73752 29.0727 8.14424 29.0727C5.77846 29.0727 2.72065 28.1023 0.32268 26.8136V33.1773C2.97815 34.3068 5.66581 34.7841 8.12815 34.7841C14.0667 34.7841 18.1546 32.2705 18.1546 27.1796C18.1546 18.7636 7.2269 20.275 7.2269 17.0932ZM103.001 22.3909C103.001 15.1523 99.4602 9.44091 92.6686 9.44091C85.8771 9.44091 81.741 15.1523 81.741 22.3432C81.741 30.8545 86.6174 34.7841 93.5699 34.7841C96.9818 34.7841 99.5407 34.0205 101.488 32.9545V27.6409C99.5407 28.6114 97.3036 29.2 94.4711 29.2C91.6869 29.2 89.2407 28.2295 88.9188 24.9205H102.904C102.936 24.5545 103.001 23.075 103.001 22.3909ZM88.8544 19.7182C88.8544 16.5364 90.8339 15.2 92.6204 15.2C94.3746 15.2 96.2414 16.5364 96.2414 19.7182H88.8544ZM70.6846 9.44091C67.8843 9.44091 66.0817 10.7455 65.0839 11.6523L64.7138 9.90227H58.4211V42.4841L65.5667 40.9886L65.5828 33.0023C66.6128 33.75 68.1417 34.7841 70.6363 34.7841C75.7541 34.7841 80.4213 31.0932 80.4213 22.1205C80.4374 13.9114 75.7058 9.44091 70.6846 9.44091ZM68.9786 28.9296C67.3049 28.9296 66.3071 28.325 65.615 27.5932L65.5667 17.0932C66.3071 16.2818 67.3371 15.6932 68.9786 15.6932C71.5858 15.6932 73.3883 18.5886 73.3883 22.2795C73.4044 26.0818 71.6341 28.9296 68.9786 28.9296ZM48.5878 34.2909H55.7657V9.91818H48.5878V34.2909Z" fill="white" />
                  </g>
                  <defs>
                    <clipPath id="clip0_3_390">
                      <rect width="103" height="42" fill="white" transform="translate(0 0.5)" />
                    </clipPath>
                  </defs>
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" width="105" height="63" viewBox="0 0 105 63" fill="none">
                  <g clip-path="url(#clip0_3_393)">
                    <path d="M29.8871 22.9887C29.7705 26.6267 31.6043 28.2378 31.6496 29.2609C31.628 29.4692 31.5565 29.6693 31.4409 29.8445C31.3254 30.0197 31.1692 30.1649 30.9855 30.268L28.9119 31.7072C28.6436 31.8937 28.3273 32.0007 27.9999 32.0156C27.9303 32.0124 26.6732 32.3095 24.6823 27.9021C23.4676 29.4054 21.9222 30.6133 20.1642 31.4332C18.4062 32.2531 16.4823 32.6633 14.5398 32.6324C11.9026 32.7753 4.75542 31.1483 5.12315 23.6038C4.86558 17.4552 10.6407 13.6357 16.6134 13.9585C17.7635 13.9617 20.1124 14.0179 24.2255 14.9656V12.4567C24.6612 8.20665 21.8441 4.90908 16.9665 5.4038C16.5777 5.4054 13.8238 5.32349 9.54072 7.02768C8.34845 7.57058 8.19617 7.48064 7.79929 7.48064C6.59891 7.48064 7.09299 4.03048 7.32302 3.59359C8.16701 2.56561 13.1321 0.64618 18.0049 0.673486C21.263 0.387784 24.5036 1.3848 27.0263 3.44903C28.0518 4.58636 28.8341 5.91798 29.3261 7.36347C29.8181 8.80895 30.0095 10.3383 29.8888 11.8592L29.8871 22.9887ZM15.8876 28.1912C21.1411 28.1157 23.3653 24.9836 23.8723 23.2971C24.2708 21.6828 24.2044 20.6613 24.2044 18.896C22.6379 18.5234 20.383 18.117 17.7959 18.1138C15.3417 17.9307 10.8593 19.0181 11.0343 23.2955C10.8334 25.9923 12.8357 28.339 15.8876 28.1912ZM43.5756 31.8935C42.3023 32.0092 41.7094 31.1129 41.5215 30.2279L33.4542 3.78152C33.2971 3.33499 33.1934 2.874 33.1432 2.40338C33.1135 2.20936 33.1626 2.01155 33.2798 1.85343C33.3971 1.69531 33.5729 1.58982 33.7685 1.56012C33.8074 1.55369 33.4235 1.56012 37.3729 1.56012C38.7952 1.41877 39.2585 2.52867 39.4059 3.22577L45.1923 25.8461L50.564 3.22577C50.6499 2.70856 51.0403 1.44768 52.6375 1.581H55.4174C55.7689 1.55209 57.2171 1.50069 57.4714 3.24665L62.8853 26.1561L68.858 3.24665C68.9357 2.89649 69.2986 1.42038 70.9121 1.581H74.1066C74.2443 1.56012 75.1028 1.45089 74.957 2.95913C74.8874 3.25628 75.5094 1.24691 66.4119 30.2488C66.2256 31.1338 65.6311 32.0301 64.3578 31.9144H61.3301C59.5579 32.0991 59.3036 30.3628 59.276 30.1877L53.9043 8.16167L48.5942 30.1652C48.5683 30.3403 48.3139 32.0766 46.5401 31.8919H43.5756V31.8935ZM87.8777 32.7978C86.9251 32.7994 82.3828 32.7496 78.5857 30.8238C78.2075 30.665 77.8853 30.3984 77.66 30.0578C77.4348 29.7173 77.3166 29.318 77.3205 28.9108V27.1841C77.3205 25.8269 78.3249 26.0758 78.7509 26.238C80.3773 26.8902 81.4206 27.3849 83.418 27.78C89.355 28.9895 91.9664 27.4106 92.6063 27.0604C94.7365 25.806 94.905 22.9357 93.4567 21.4467C91.759 20.0348 90.9491 19.9818 84.85 18.0736C84.0984 17.8664 77.7709 15.8876 77.7563 9.66349C77.6575 5.12753 81.8142 0.639755 89.0181 0.676698C91.0706 0.675092 96.5395 1.34007 98.0201 3.18561C98.2388 3.52131 98.3473 3.91644 98.3311 4.31639V5.94027C98.3311 6.65343 98.0687 7.01001 97.5422 7.01001C96.2932 6.87188 94.0772 5.21587 89.5786 5.28333C88.4625 5.22551 83.1167 5.4295 83.3564 9.29406C83.2868 12.3394 87.6671 13.4815 88.1676 13.6132C94.0739 15.3752 96.0486 15.6675 98.3927 18.3644C101.169 21.9382 99.6724 26.1224 99.0974 27.2692C96.0065 33.2909 88.0137 32.801 87.8777 32.7978ZM94.3898 49.6406C83.0454 57.948 66.5771 62.3699 52.516 62.3699C33.5434 62.494 15.2102 55.5768 1.12028 42.978C0.062465 42.032 0.995549 40.7358 2.28178 41.457C17.9117 50.3219 35.608 54.9799 53.6144 54.9685C67.061 54.897 80.361 52.1922 92.7504 47.0097C94.6587 46.2065 96.277 48.2625 94.3898 49.6406ZM99.1184 44.2935C97.6669 42.4432 89.5154 43.4294 85.8657 43.8615C84.7658 43.9851 84.5795 43.0391 85.5757 42.3404C92.0668 37.8157 102.728 39.1119 103.952 40.633C105.175 42.1541 103.62 52.7455 97.5438 57.805C96.6107 58.5873 95.7182 58.1745 96.1329 57.1465C97.5001 53.7333 100.57 46.1455 99.1184 44.2935Z" fill="white" />
                  </g>
                  <defs>
                    <clipPath id="clip0_3_393">
                      <rect width="104" height="62" fill="white" transform="translate(0.5 0.5)" />
                    </clipPath>
                  </defs>
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" width="77" height="73" viewBox="0 0 77 73" fill="none">
                  <g clip-path="url(#clip0_3_396)">
                    <path d="M67.926 28.1615C65.5311 28.1615 63.4235 29.1557 61.8748 30.7111C56.1748 26.7503 48.4949 24.2007 39.9848 23.9281L44.4075 3.91559L58.4899 7.09064C58.4899 10.5543 61.3 13.3766 64.7487 13.3766C68.2613 13.3766 71.0874 10.4742 71.0874 7.01046C71.0874 3.54677 68.2773 0.644318 64.7487 0.644318C62.2899 0.644318 60.1664 2.13563 59.1126 4.17216L43.5613 0.70846C42.779 0.499997 42.0126 1.06124 41.805 1.84699L36.9512 23.912C28.505 24.2648 20.905 26.8145 15.1891 30.7753C13.6403 29.1557 11.4529 28.1615 9.05796 28.1615C0.180651 28.1615 -2.72523 40.124 5.40166 44.2131C5.11426 45.4799 4.98653 46.8269 4.98653 48.1739C4.98653 61.6118 20.0588 72.5 38.5638 72.5C57.1487 72.5 72.221 61.6118 72.221 48.1739C72.221 46.8269 72.0773 45.4158 71.726 44.149C79.6933 40.0439 76.7554 28.1615 67.926 28.1615ZM18.2865 45.063C18.2865 41.5352 21.0966 38.6969 24.6252 38.6969C28.0739 38.6969 30.884 41.5191 30.884 45.063C30.884 48.5267 28.0739 51.349 24.6252 51.349C21.1126 51.365 18.2865 48.5267 18.2865 45.063ZM52.5025 60.0563C46.6907 65.8933 30.2933 65.8933 24.4815 60.0563C23.8428 59.4951 23.8428 58.5009 24.4815 57.8595C25.0403 57.2982 26.0302 57.2982 26.5891 57.8595C31.0277 62.4296 45.7487 62.5098 50.379 57.8595C50.9378 57.2982 51.9277 57.2982 52.4865 57.8595C53.1412 58.5009 53.1412 59.4951 52.5025 60.0563ZM52.3748 51.365C48.926 51.365 46.1159 48.5427 46.1159 45.0791C46.1159 41.5512 48.926 38.7129 52.3748 38.7129C55.8874 38.7129 58.7134 41.5352 58.7134 45.0791C58.6975 48.5267 55.8874 51.365 52.3748 51.365Z" fill="white" />
                  </g>
                  <defs>
                    <clipPath id="clip0_3_396">
                      <rect width="76" height="72" fill="white" transform="translate(0.5 0.5)" />
                    </clipPath>
                  </defs>
                </svg>

              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Hero Section End */}


      {/* popup start */}

      <div>
        {isPopupOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            <div className="absolute inset-0 bg-gray-800 opacity-75"></div>
            <div className="z-50 bg-gray-800 opacity-75 p-6 rounded-lg shadow-lg">
              <div className="flex justify-end">
                <span onClick={closePopup} className="cursor-pointer text-gray-500 hover:text-gray-700">
                  &times;
                </span>
              </div>
              <div className="mt-4">


                {/* <p>{data[0].name}</p> */}
                <p className="text-[#ffff]">{data}</p>


              </div>
            </div>
          </div>
        )}
      </div>

      {/* popup start */}

      {/* Blue Line Start */}
      <div className="bg-white-A700 flex flex-col items-center justify-end mt-[-108px] mx-auto pt-[40px] md:px-10 sm:px-5 w-full z-[1]">
        <div className="flex md:flex-col flex-row md:gap-10 items-center justify-between mt-6 w-[85%] md:w-full">
          <div className="flex flex-col gap-3 md:gap-[38px] h-[400px] items-start justify-start w-[30%] ml-[150px] md:w-full">
            <Text
              className="sm:text-[40px] md:text-[46px] text-[40px] text-gray-900_01 tracking-[-1.10px]"
              size="txtMontserratBold50"
            >
              Who we are
            </Text>
            <div className="flex flex-col relative w-full pt-5">
              <Text
                className="leading-[150.00%] mx-auto text-[px] md:text-[22px] text-gray-600 sm:text-xl tracking-[-0.46px] w-full"
                size="txtMontserratMedium24"
              >
                <span className="text-blue-900 font-montserrat text-left font-bold">
                  TurboHealth.us
                </span>
                <span className="text-gray-600 font-montserrat text-left font-medium">
                  <>
                    {" "}
                    is here to simplify the process for you. We&#39;re
                    your trusted partner in finding the perfect healthcare
                    coverage tailored to your needs. Whether you&#39;re an
                    individual, family, or business,{" "}
                  </>
                </span>
                <br />
                <span className="text-blue-900 font-montserrat text-left font-bold">
                  TurboHealth.us
                </span>
                <span className="text-gray-600 font-montserrat text-left font-medium">
                  <>
                    {" "}
                    has the right insurance solution for you. Let&#39;s
                    embark on a journey to secure your well-being and
                    peace of mind.
                  </>
                </span>
              </Text>
              <Button
                className="!bg-colors1 cursor-pointer font-bold h-10 mt-[30px] rounded-[10px] text-[10px] text-center text-white-A700 tracking-[0.20px] w-[110px] z-[1]"
                shape="round"
                color="pink_600"
                size="lg"
                variant="fill"
              >
                Learn More
              </Button>
            </div>
          </div>
          <div className="md:h-[421px] h-[425px] relative w-[42%] md:w-full">
            <Img
              className="absolute h-[300px] left-[0] ml-[50px] object-cover rounded-[10px] top-[0] w-[59%]"
              src="images/img_rectangle278.png"
              alt="rectangle278"
            />
            <Img
              className="absolute bottom-[0] mr-[70px] h-[250px] object-cover right-[0] rounded-[10px] w-[55%]"
              src="images/img_rectangle279.png"
              alt="rectangle279"
            />
          </div>
        </div>
      </div>
      {/* Blue Line End */}


      {/* Who We are section Start */}
      <div className="bg-white-A700 flex flex-col items-center justify-end mt-[108px] mx-auto pt-[40px] md:px-10 sm:px-5 w-full ">
        <Text
          className="md:ml-[0]  sm:text-[40px] md:text-[46px] text-[40px] text-gray-900_01 tracking-[1.10px]"
          size="txtMontserratBold50"
        >
          What is TurboHealth
        </Text>


        <List
          className="sm:flex-col flex-row md:gap-10 gap-[62px] grid sm:grid-cols-1 md:grid-cols-2 grid-cols-3 justify-center mt-[70px]  mx-auto md:px-5 w-[80%]"
          orientation="horizontal"
        >
          <div className="flex sm:flex-1 flex-col items-start justify-start w-[462px] py sm:w-full">
            <div className="bg-white-A700 py-[30px] flex flex-col gap-[14.09px] items-start justify-start md:px-10 sm:px-5 px-[56.37px] py-[49.32px] shadow-bs2 w-[400px] sm:w-full">
              <Img
                className="h-[40px] w-[50px]"
                src="images/img_icnresizeicnmd.svg"
                alt="icnresizeicnmd"
              />
              <Text
                className="sm:text-[2.82px] md:text-[18.82px] text-[22.82px] text-blue_gray-900 tracking-[0.14px] w-auto"
                size="txtMontserratBold3382"
              >
                Peace of Mind
              </Text>
              <Text
                className="leading-[28.00px] text-[13.73px] text-gray-600 tracking-[0.28px]"
                size="txtMontserratMedium1973"
              >
                <>
                  the quick fox jumps over the <br />
                  lazy dog
                </>
              </Text>
            </div>
          </div>
          <div className="flex sm:flex-1 flex-col items-start justify-start w-[462px] py sm:w-full">
            <div className="bg-white-A700 py-[30px] flex flex-col gap-[14.09px] items-start justify-start md:px-10 sm:px-5 px-[56.37px] py-[49.32px] shadow-bs2 w-[400px] sm:w-full">
              <Img
                className="h-[40px] w-[50px]"
                src="images/img_icnresizeicnmd.svg"
                alt="icnresizeicnmd"
              />
              <Text
                className="sm:text-[2.82px] md:text-[18.82px] text-[22.82px] text-blue_gray-900 tracking-[0.14px] w-auto"
                size="txtMontserratBold3382"
              >
                Peace of Mind
              </Text>
              <Text
                className="leading-[28.00px] text-[13.73px] text-gray-600 tracking-[0.28px]"
                size="txtMontserratMedium1973"
              >
                <>
                  the quick fox jumps over the <br />
                  lazy dog
                </>
              </Text>
            </div>
          </div>

          <div className="flex sm:flex-1 flex-col items-start justify-start w-[462px] sm:w-full">
            <div className="bg-blue-900 py-[30px] flex flex-col gap-[14.09px] items-start justify-start md:px-10 sm:px-5 px-[56.37px] py-[49.32px] shadow-bs2 w-[400px] sm:w-full">
              <Img
                className="h-[40px] w-[50px]"
                src="images/img_icnresizeicnmd_white_a700.svg"
                alt="icnresizeicnmd"
              />
              <Text
                className="sm:text-[18.82px] md:text-[18.82px] text-[22.82px] text-white-A700 tracking-[0.14px] w-auto"
                size="txtMontserratBold3382WhiteA700"
              >
                100% Satisfaction
              </Text>
              <Text
                className="leading-[28.00px] text-[13.73px] text-white-A700 tracking-[0.28px]"
                size="txtMontserratMedium1973WhiteA700"
              >
                <>
                  the quick fox jumps over the <br />
                  lazy dog
                </>
              </Text>
            </div>
          </div>
        </List>

      </div>
      {/* Who we are section end */}


      {/* How it work section start */}
      <div>

        <div className="bg-gray-100 grid grid-cols-1  mt-[225px] mx-auto pt-[40px] md:px-10 sm:px-5 w-full">
          <Text
            className="md:ml-[0] text-center sm:text-[40px] md:text-[46px] text-[40px] text-gray-900_01 tracking-[1.10px]"
            size="txtMontserratBold50"
          >
            How it works
          </Text>
          <Text
            className="mt-[25px] text-[19.73px] text-center text-gray-600 tracking-[0.28px]"
            size="txtMontserratMedium1973"
          >
            the quick fox jumps over the lazy dog
          </Text>
        </div>
        <div className="bg-gray-100 grid grid-cols-4  pl-[15%] pt-[40px] md:px-10 sm:px-5">
          <div className="col-start-1 col-span-3">
            <div className="flex flex-col">
              <div className="container  w-[100%] mx-auto flex items-center justify-between mt-8">
                {/* First Component - Round Div */}
                <div className="">
                  <div className="bg-white-A700 h-[150px] rounded-[50%] w-[150px]  w-[15%] "></div>
                </div>


                {/* Second Component - Dotted Line and Round Circle */}
                <div className="relative  flex items-center mx-4 w-[10%]"> {/* Added margin between components */}
                  {/* Dotted Line */}
                  <div className="w-0.5 h-20 bg-black mr-4"></div> {/* Added margin to make the line visible */}

                  {/* Round Circle */}
                  <div className="bg-pink-600 h-8 w-8 rounded-full">

                  </div>
                </div>

                {/* Third Component */}
                <div className="flex flex-col items-start w-[40%] mr-[24%]">
                  <Button
                    className="cursor-pointer font-semibold font-thin min-w-[100px] rounded  text-[16px] text-center"

                    color="pink_600"
                    size="xs"
                    variant="fill"
                  >
                    See what{" "}
                  </Button>
                  <Text
                    className="mt-[10px] sm:text-[21px] md:text-[23px] text-[18px] text-gray-800 tracking-[-0.55px]"
                    size="txtMontserratSemiBold25"
                  >
                    See what savings you qualify for
                  </Text>
                  <Text
                    className="leading-[143.50%] mt-[10px] sm:text-[21px] md:text-[23px] text-[15px] text-gray-600 tracking-[-0.55px] w-full"
                    size="txtMontserratMedium25Gray600"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing
                    elit. Donec non erat eros. Fusce mattis sed nulla
                    ultricies sodales.
                  </Text>
                </div>
              </div>
            </div>


            <div className="flex flex-col">
              <div className="container  w-[100%] mx-auto flex items-center justify-between mt-[15%]">
                {/* First Component - Round Div */}
                <div className="">
                  <div className="bg-white-A700 h-[150px] rounded-[50%] w-[150px]  w-[15%] "></div>
                </div>


                {/* Second Component - Dotted Line and Round Circle */}
                <div className="relative  flex items-center mx-4 w-[10%]"> {/* Added margin between components */}
                  {/* Dotted Line */}
                  <div className="w-0.5 h-20 bg-black mr-4"></div> {/* Added margin to make the line visible */}

                  {/* Round Circle */}
                  <div className="bg-pink-600 h-8 w-8 rounded-full">

                  </div>
                </div>

                {/* Third Component */}
                <div className="flex flex-col items-start w-[40%] mr-[24%]">
                  <Button
                    className="cursor-pointer font-semibold font-thin min-w-[100px] rounded  text-[16px] text-center"

                    color="pink_600"
                    size="xs"
                    variant="fill"
                  >
                    See what{" "}
                  </Button>
                  <Text
                    className="mt-[10px] sm:text-[21px] md:text-[23px] text-[18px] text-gray-800 tracking-[-0.55px]"
                    size="txtMontserratSemiBold25"
                  >
                    See what savings you qualify for
                  </Text>
                  <Text
                    className="leading-[143.50%] mt-[10px] sm:text-[21px] md:text-[23px] text-[15px] text-gray-600 tracking-[-0.55px] w-full"
                    size="txtMontserratMedium25Gray600"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing
                    elit. Donec non erat eros. Fusce mattis sed nulla
                    ultricies sodales.
                  </Text>
                </div>
              </div>
            </div>
            <div className="flex flex-col">
              <div className="container  w-[100%] mx-auto flex items-center justify-between mt-[15%]">
                {/* First Component - Round Div */}
                <div className="">
                  <div className="bg-white-A700 h-[150px] rounded-[50%] w-[150px]  w-[15%] "></div>
                </div>


                {/* Second Component - Dotted Line and Round Circle */}
                <div className="relative  flex items-center mx-4 w-[10%]"> {/* Added margin between components */}
                  {/* Dotted Line */}
                  <div className="w-0.5 h-20 bg-black mr-4"></div> {/* Added margin to make the line visible */}

                  {/* Round Circle */}
                  <div className="bg-pink-600 h-8 w-8 rounded-full">

                  </div>
                </div>

                {/* Third Component */}
                <div className="flex flex-col items-start w-[40%] mr-[24%]">
                  <Button
                    className="cursor-pointer font-semibold font-thin min-w-[100px] rounded  text-[16px] text-center"

                    color="pink_600"
                    size="xs"
                    variant="fill"
                  >
                    See what{" "}
                  </Button>
                  <Text
                    className="mt-[10px] sm:text-[21px] md:text-[23px] text-[18px] text-gray-800 tracking-[-0.55px]"
                    size="txtMontserratSemiBold25"
                  >
                    See what savings you qualify for
                  </Text>
                  <Text
                    className="leading-[143.50%] mt-[10px] sm:text-[21px] md:text-[23px] text-[15px] text-gray-600 tracking-[-0.55px] w-full"
                    size="txtMontserratMedium25Gray600"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing
                    elit. Donec non erat eros. Fusce mattis sed nulla
                    ultricies sodales.
                  </Text>
                </div>
              </div>
            </div>
            <div className="flex flex-col">
              <div className="container  w-[100%] mx-auto flex items-center justify-between mt-[15%]">
                {/* First Component - Round Div */}
                <div className="">
                  <div className="bg-white-A700 h-[150px] rounded-[50%] w-[150px]  w-[15%] "></div>
                </div>


                {/* Second Component - Dotted Line and Round Circle */}
                <div className="relative  flex items-center mx-4 w-[10%]"> {/* Added margin between components */}
                  {/* Dotted Line */}
                  <div className="w-0.5 h-20 bg-black mr-4"></div> {/* Added margin to make the line visible */}

                  {/* Round Circle */}
                  <div className="bg-pink-600 h-8 w-8 rounded-full">

                  </div>
                </div>

                {/* Third Component */}
                <div className="flex flex-col items-start w-[40%] mr-[24%]">
                  <Button
                    className="cursor-pointer font-semibold font-thin min-w-[100px] rounded  text-[16px] text-center"

                    color="pink_600"
                    size="xs"
                    variant="fill"
                  >
                    See what{" "}
                  </Button>
                  <Text
                    className="mt-[10px] sm:text-[21px] md:text-[23px] text-[18px] text-gray-800 tracking-[-0.55px]"
                    size="txtMontserratSemiBold25"
                  >
                    See what savings you qualify for
                  </Text>
                  <Text
                    className="leading-[143.50%] mt-[10px] sm:text-[21px] md:text-[23px] text-[15px] text-gray-600 tracking-[-0.55px] w-full"
                    size="txtMontserratMedium25Gray600"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing
                    elit. Donec non erat eros. Fusce mattis sed nulla
                    ultricies sodales.
                  </Text>
                </div>
              </div>
            </div>


          </div>

          <div className="text-end">
            <Img
              className="h-[1200px] md:h-auto object-cover float-right"
              src="images/img_bg.png"
              alt="bg"
            />
          </div>
        </div>

      </div>
      {/* How it work section end */}


      {/* Saving member Suport section start */}
      <div className="bg-blue-900 items-center p-10 grid grid-cols-3 gap-4">
        <div className="flex flex-col gap-[5px] items-center justify-start">
          <Text
            className=" md:text-5xl text-[70.76px] text-center text-white-A700 tracking-[0.41px]"
            size="txtMontserratBold10176"
          >
            $224+
          </Text>
          <Text
            className="sm:text-[34.93px] md:text-[36.93px] text-[26.93px] text-center text-white-A700 tracking-[0.16px]"
            size="txtMontserratMedium3893"
          >
            SAVINGS
          </Text>
        </div>
        <div className="flex flex-col gap-1.5 items-center justify-start">
          <Text
            className="md:text-5xl text-[70.76px] text-center text-white-A700 tracking-[0.41px]"
            size="txtMontserratBold10176"
          >
            72 M+
          </Text>
          <Text
            className="sm:text-[34.93px] md:text-[36.93px] text-[26.93px] text-center text-white-A700 tracking-[0.16px]"
            size="txtMontserratMedium3893"
          >
            MEMBERS
          </Text>
        </div>
        <div className="flex flex-col gap-1.5 items-center justify-start">
          <Text
            className="md:text-5xl text-[70.76px] text-center text-white-A700 tracking-[0.41px]"
            size="txtMontserratBold10176"
          >
            24 Hr
          </Text>
          <Text
            className="sm:text-[34.93px] md:text-[36.93px] text-[26.93px] text-center text-white-A700 tracking-[0.16px]"
            size="txtMontserratMedium3893"
          >
            SUPPORT
          </Text>
        </div>
      </div>
      {/* Saving member Suport section End */}



      {/* Man With pic And How it work Section start */}

      <div className="mt-[200px]">
        <div className="flex flex-col  items-center  md:ml-[0]  md:px-5">
          <Text
            className="md:ml-[0] text-center sm:text-[40px] md:text-[46px] text-[40px] text-gray-900_01 tracking-[1.10px]"
            size="txtMontserratBold50"
          >
            How it works
          </Text>
          <Text
            className="mt-[25px] text-[19.73px] text-center text-gray-600 tracking-[0.28px]"
            size="txtMontserratMedium1973"
          >
            the quick fox jumps over the lazy dog
          </Text>
        </div>

        <div className=" h-[1000px] mt-[100px] relative w-full">
          <div className="absolute bg-gray-100_01 bottom-[0]  h-[750px] inset-x-[0]  ml-[10%] rounded-l-lg w-[90%]"></div>
          <div
            className="absolute bg-cover bg-no-repeat flex flex-col h-[95%] inset-y-[0]  justify-end my-auto ml-10 md:px-10 sm:px-5 right-[0] w-[70%]"
            style={{
              backgroundImage: "url('images/img_group202.png')",
            }}
          >

            <div className="absolute flex flex-col h-[100%] inset-y-[0] items-start justify-start right-[80%] my-[60px] w-[40%]">
              <Img
                className="h-[500px] md:h-auto object-cover rounded-[10px]  w-full"
                src="images/img_rectangle270.png"
                alt="rectangle270"
              />
            </div>
            <div className="flex flex-col md:gap-10 gap-[80px] justify-start mt-[345px] w-3/4 md:w-full">
              <div className="flex flex-col items-start justify-start md:ml-[0] ml-[342px]  w-[61%] md:w-full">
                <Text
                  className="sm:text-4xl md:text-[38px] text-[25px]  text-gray-800 tracking-[-0.88px]"
                  size="txtMontserratBold40"
                >
                  Albert John
                </Text>
                <Text
                  className="mt-[26px] text-[17px] sm:text-[26px] md:text-[28px] text-gray-800 tracking-[-0.66px]"
                  size="txtMontserratSemiBold30"
                >
                  See what savings you qualify for
                </Text>
                <Text
                  className="leading-[150%] mt-7 w-[80%] sm:text-[21px] md:text-[23px] text-[16px] text-gray-600 tracking-[-0.55px] w-full"
                  size="txtMontserratMedium25Gray600"
                >
                  Lorem ipsum dolor sit amet, consectetur adipiscing
                  elit. Donec non erat eros. Fusce mattis sed nulla
                  ultricies sodales.{" "}
                </Text>
                <div className="flex flex-row gap-[8px] pt-[30px] items-center justify-start md:ml-[0] ml-[5px] mt-[20px] w-[14%] md:w-full">
                  <Img
                    className="h-[20px]  w-[20px]"
                    src="images/img_arrowleft.svg"
                    alt="arrowleft"
                  />
                  <Img
                    className="h-[20px] w-[20px]"
                    src="images/img_arrowleft_pink_600.svg"
                    alt="arrowleft_One"
                  />
                </div>
              </div>
              <div className="flex mb-[60px] mr-[50px]">
                <Img
                  className="h-[270px] md:h-auto object-cover rounded-[10px] mr-5"
                  src="images/img_rectangle272.png"
                  alt="rectangle272"
                />
                <Img
                  className="h-[270px] md:h-auto object-cover rounded-[10px] mr-5"
                  src="images/img_rectangle272.png"
                  alt="rectangle273"
                />
                <Img
                  className="h-[270px] md:h-auto object-cover rounded-[10px] mr-5"
                  src="images/img_rectangle272.png"
                  alt="rectangle274"
                />
                <Img
                  className="h-[270px] md:h-auto object-cover rounded-[10px]"
                  src="images/img_rectangle272.png"
                  alt="rectangle274"
                />
              </div>
            </div>


          </div>
        </div>












        {/* <div className="md:h-[1166px] h-[1301px] m-[100px] sm:h-[2007px] md:px-5 relative w-full">
          <div className="absolute md:h-[1166px] h-[1301px] sm:h-[2007px] inset-y-[0] left-[0] my-auto w-[94%] md:w-full">
            <div className="absolute bg-gray-100_01 bottom-[0] h-[999px] inset-x-[0] mx-auto rounded-[35px] w-full"></div>
            <div
              className="absolute bg-cover bg-no-repeat flex flex-col h-[95%] inset-y-[0] justify-end my-auto p-12 md:px-10 sm:px-5 right-[0] w-[86%]"
              style={{
                backgroundImage: "url('images/img_group202.png')",
              }}
            >
              <div className="flex flex-col md:gap-10 gap-[139px] justify-start mt-[345px] w-3/4 md:w-full">
                <div className="flex flex-col items-start justify-start md:ml-[0] ml-[342px] w-[61%] md:w-full">
                  <Text
                    className="sm:text-4xl md:text-[38px] text-[40px] text-gray-800 tracking-[-0.88px]"
                    size="txtMontserratBold40"
                  >
                    Albert John
                  </Text>
                  <Text
                    className="mt-[26px] text-3xl sm:text-[26px] md:text-[28px] text-gray-800 tracking-[-0.66px]"
                    size="txtMontserratSemiBold30"
                  >
                    See what savings you qualify for
                  </Text>
                  <Text
                    className="leading-[143.50%] mt-7 sm:text-[21px] md:text-[23px] text-[25px] text-gray-600 tracking-[-0.55px] w-full"
                    size="txtMontserratMedium25Gray600"
                  >
                    Lorem ipsum dolor sit amet, consectetur adipiscing
                    elit. Donec non erat eros. Fusce mattis sed nulla
                    ultricies sodales.{" "}
                  </Text>
                  <div className="flex flex-row gap-[22px] items-center justify-start md:ml-[0] ml-[5px] mt-[54px] w-[14%] md:w-full">
                    <Img
                      className="h-[31px] w-[31px]"
                      src="images/img_arrowleft.svg"
                      alt="arrowleft"
                    />
                    <Img
                      className="h-[31px] w-[31px]"
                      src="images/img_arrowleft_pink_600.svg"
                      alt="arrowleft_One"
                    />
                  </div>
                </div>
                <div className="flex sm:flex-col flex-row sm:gap-10 items-center justify-between w-full">
                  <Img
                    className="h-[331px] md:h-auto object-cover rounded-[10px]"
                    src="images/img_rectangle272.png"
                    alt="rectangle272"
                  />
                  <Img
                    className="h-[331px] md:h-auto object-cover rounded-[10px]"
                    src="images/img_rectangle272.png"
                    alt="rectangle273"
                  />
                  <Img
                    className="h-[331px] md:h-auto object-cover rounded-[10px]"
                    src="images/img_rectangle272.png"
                    alt="rectangle274"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="absolute flex flex-col md:gap-10 gap-[106px] h-max inset-y-[0] items-start justify-start left-[4%] my-auto w-[32%]">
            <Img
              className="h-[665px] md:h-auto object-cover rounded-bl-[10px] rounded-br-[10px] w-full"
              src="images/img_rectangle270.png"
              alt="rectangle270"
            />
            <Img
              className="h-[331px] md:h-auto object-cover rounded-[10px] w-1/2"
              src="images/img_rectangle272.png"
              alt="rectangle271"
            />
          </div>
          <Img
            className="absolute bottom-[6%] h-[331px] object-cover right-[0] rounded-[10px] w-[16%]"
            src="images/img_rectangle272.png"
            alt="rectangle275"
          />
        </div> */}


        {/* <div className="bg-white-A700 flex flex-col items-center justify-start max-w-[1440px] mt-[158px] mx-auto pl-5 md:pr-5 pt-5 w-full">
            <div className="flex flex-col items-center justify-start mt-5 w-full">
              <Text
                className="sm:text-[40px] md:text-[46px] text-[50px] text-center text-gray-800"
                size="txtMontserratBold50Gray800"
              >
                Frequently asked questions
              </Text>
              <Text
                className="mt-5 text-center text-gray-900_8e text-xl"
                size="txtMontserratMedium20"
              >
                Get the best services at the lowest price
              </Text>
              <div className="flex flex-col items-center justify-start mt-[78px] w-full">
                <div className="md:gap-5 gap-[182px] grid sm:grid-cols-1 md:grid-cols-2 grid-cols-3 justify-center min-h-[auto] w-full">
                  {new Array(6).fill({}).map((props, index) => (
                    <React.Fragment key={`Slide169OneNaked${index}`}>
                      <Slide169OneNaked
                        className="flex flex-1 flex-col gap-5 items-start justify-start w-full"
                        {...props}
                      />
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </div>
          </div> */}




      </div>

      {/* Man With pic And How it work Section start */}



      {/* Questions Start */}
      <div className="bg-white-A700 flex flex-col items-center justify-start max-w-[1440px] mt-[70px] mx-auto pl-5 md:pr-5 pt-5 w-full">
        <div className="flex flex-col items-center justify-start mt-5 w-full">
          <Text
            className="sm:text-[40px] md:text-[46px] text-[30px] text-center text-gray-800"
            size="txtMontserratBold50Gray800"
          >
            Frequently asked questions
          </Text>
          <Text
            className="mt-5 text-center text-gray-900_8e text-[16px]"
            size="txtMontserratMedium20"
          >
            Get the best services at the lowest price
          </Text>
          <div className="flex flex-col items-center justify-start mt-[78px] w-full">
            <div className="md:gap-5 gap-[60px] grid sm:grid-cols-1 md:grid-cols-2 grid-cols-3 justify-center min-h-[auto] w-[80%]">

              <div className="flex flex-col gap-3 items-start justify-start w-full">
                <Text
                  className="text-gray-900_02 text-[20px] w-full"
                  size="txtMontserratSemiBold20"
                >
                  How long do payouts take?
                </Text>
                <Text
                  className="leading-[150.00%] max-w-[360px] md:max-w-full text-gray-900_8e text-[16px]"
                  size="txtPoppinsRegular20"
                >
                  Once you’re set up, payouts arrive in your bank account on a 2-day rolling basis. Or you can opt to receive payouts weekly or monthly.
                </Text>
              </div>
              <div className="flex flex-col gap-3 items-start justify-start w-full">
                <Text
                  className="text-gray-900_02 text-[20px] w-full"
                  size="txtMontserratSemiBold20"
                >
                  How long do payouts take?
                </Text>
                <Text
                  className="leading-[150.00%] max-w-[360px] md:max-w-full text-gray-900_8e text-[16px]"
                  size="txtPoppinsRegular20"
                >
                  Once you’re set up, payouts arrive in your bank account on a 2-day rolling basis. Or you can opt to receive payouts weekly or monthly.
                </Text>
              </div>
              <div className="flex flex-col gap-3 items-start justify-start w-full">
                <Text
                  className="text-gray-900_02 text-[20px] w-full"
                  size="txtMontserratSemiBold20"
                >
                  How long do payouts take?
                </Text>
                <Text
                  className="leading-[150.00%] max-w-[360px] md:max-w-full text-gray-900_8e text-[16px]"
                  size="txtPoppinsRegular20"
                >
                  Once you’re set up, payouts arrive in your bank account on a 2-day rolling basis. Or you can opt to receive payouts weekly or monthly.
                </Text>
              </div>
              <div className="flex flex-col gap-3 items-start justify-start w-full">
                <Text
                  className="text-gray-900_02 text-[20px] w-full"
                  size="txtMontserratSemiBold20"
                >
                  How long do payouts take?
                </Text>
                <Text
                  className="leading-[150.00%] max-w-[360px] md:max-w-full text-gray-900_8e text-[16px]"
                  size="txtPoppinsRegular20"
                >
                  Once you’re set up, payouts arrive in your bank account on a 2-day rolling basis. Or you can opt to receive payouts weekly or monthly.
                </Text>
              </div>
              <div className="flex flex-col gap-3 items-start justify-start w-full">
                <Text
                  className="text-gray-900_02 text-[20px] w-full"
                  size="txtMontserratSemiBold20"
                >
                  How long do payouts take?
                </Text>
                <Text
                  className="leading-[150.00%] max-w-[360px] md:max-w-full text-gray-900_8e text-[16px]"
                  size="txtPoppinsRegular20"
                >
                  Once you’re set up, payouts arrive in your bank account on a 2-day rolling basis. Or you can opt to receive payouts weekly or monthly.
                </Text>
              </div>
              <div className="flex flex-col gap-3 items-start justify-start w-full">
                <Text
                  className="text-gray-900_02 text-[20px] w-full"
                  size="txtMontserratSemiBold20"
                >
                  How long do payouts take?
                </Text>
                <Text
                  className="leading-[150.00%] max-w-[360px] md:max-w-full text-gray-900_8e text-[16px]"
                  size="txtPoppinsRegular20"
                >
                  Once you’re set up, payouts arrive in your bank account on a 2-day rolling basis. Or you can opt to receive payouts weekly or monthly.
                </Text>
              </div>
              {/* {new Array(6).fill({}).map((props, index) => (
                <React.Fragment key={`Slide169OneNaked${index}`}>
                  <Slide169OneNaked
                    className="flex flex-1 flex-col gap- items-start justify-start w-full"
                    {...props}
                  />
                </React.Fragment>
              ))} */}
            </div>
          </div>
        </div>
      </div>


      {/* Questions End */}


      {/* World map section start */}
      <div className="h-[750px] sm:h-[1063px] md:h-[1362px] mt-[193px] md:px-5 relative w-full">
        <div className="absolute bg-blue-900 flex flex-col pb-[150px] inset-x-[0] items-center justify-start mx-auto p-[100px] md:px-10 sm:px-5 top-[0] w-full">
          <div className="flex md:flex-col flex-row  items-center justify-start mb-[100px] w-auto md:w-full">
            <div className="flex flex-col pb-[] items-start justify-start  w-[60%] md:w-full">
              <Text
                className="leading-[47.00px] sm:text-4xl md:text-[38px] text-[25px] text-white-A700 tracking-[0.20px]"
                size="txtMontserratBold40WhiteA700"
              >
                <>
                  We Have Branches All <br />
                  Over The World
                </>
              </Text>
              <Text
                className="leading-[24.00px] sm:text-[21px] md:text-[23px] text-[14px] text-white-A700 tracking-[0.20px]"
                size="txtMontserratMedium25WhiteA700"
              >
                <>
                  The gradual accumulation of information about atomic and{" "}
                  <br />
                  small-scale behaviour during the first quarter of the 20th{" "}
                  <br />
                  century, which gave some indications about how small
                  things <br />
                  do behave, produced an increasing confusion which was{" "}
                  <br />
                  Heisenberg, and Born.
                </>
              </Text>
            </div>
            <div className="flex flex-col items-center justify-start py-[50px] w-[416px] sm:w-full">
              <Img
                className="h-[169px] sm:h-auto object-cover w-[414px] md:w-full"
                src="images/img_pngwing1.png"
                alt="pngwingOne"
              />
            </div>
          </div>
        </div>
        <div className="absolute bottom-[0] flex flex-col inset-x-[0] items-center justify-start mx-auto w-[58%]">
          <div className="flex sm:flex-col flex-row gap-1.5 items-center justify-center w-[52%] md:w-full">
            {/* Medicare Button */}
            <Button
              className={`${activeButton === 'medicare'
                ? '!text-pink-600 border-pink-600 border-solid border-t-2 font-bold'
                : 'capitalize'
                } capitalize cursor-pointer border-solid border-t-2 border-600 min-w-[150px] md:min-w-[120px] lg:min-w-[160px] rounded-tl-[10px] rounded-tr-[10px] text-600 text-center tracking-[0.26px]`}
              color="white_A700"
              size="xl"
              variant="fill"
              onClick={() => {
                handleButtonClick('medicare');
                setCatigory('Medicare')
              }}
            >
              Medicare
            </Button>

            {/* Individuals & family Button */}
            <Button
              className={`${activeButton === 'individuals'
                ? '!text-pink-600 border-pink-600 border-solid border-t-2 font-bold'
                : 'capitalize'
                } capitalize cursor-pointer border-solid border-t-2 border-600 min-w-[200px] md:min-w-[240px] lg:min-w-[240px] rounded-tl-[10px] rounded-tr-[10px] text-600 text-center tracking-[0.26px]`}
              color="white_A700"
              size="xl"
              variant="fill"
              onClick={() => {
                handleButtonClick('individuals');
                setCatigory("Individuals & Family")
              }}
            >
              Individuals & Family
            </Button>
            <Button
              className={`${activeButton === 'dental'
                ? '!text-pink-600 border-pink-600 border-solid border-t-2  font-bold'
                : 'capitalize'
                } capitalize -600 cursor-pointer border-solid border-t-2 border-600 min-w-[200px] md:min-w-[180px] lg:min-w-[220px] rounded-tl-[10px] rounded-tr-[10px] text-600 text-center tracking-[0.26px]`}
              color="white_A700"
              size="xl"
              variant="fill"
              onClick={() => {
                handleButtonClick('dental');
                setCatigory("Dental & Vision")
              }}
            >
              Dental & Vision
            </Button>
          </div>

          {/* Content with ZIP code input */}
          <div className="bg-white-A700 flex flex-col items-center justify-end p-8 md:px-10 sm:px-5 rounded-[10px] shadow-bs1 w-full">
            <Text
              className="capitalize text-center text-gray-800 text-[14px] tracking-[0.26px]"
              size="txtMontserratBold20"
            >
              Compare Medicare plans and enroll online. easy. fast
            </Text>
            <Text
              className="capitalize mt-5 text-center text-gray-800 text-[14px] tracking-[0.26px]"
              size="txtMontserratRegular20"
            >
              Enter your zIP code
            </Text>
            <div className="bg-white-A700  h-[44px] mt-[20px] rounded-[10px] w-[76%]">
              {/* ZIP code input */}
              <input
                type="text"
                value={zipCode}
                onChange={(e) => setZipCode(e.target.value)}
                className="w-full h-full outline-gray-800 rounded-[10px] text-gray-800 px-4"
                placeholder="Enter ZIP code"
              />
            </div>
            <Button
              className="cursor-pointer font-bold h-[44px] min-w-[200px] mt-[25px] text-center text-[14px] tracking-[0.20px]"
              shape="round"
              color="blue_900"
              size="lg"
              variant="fill"
            >
              Find medicare plans
            </Button>
          </div>
        </div>
      </div>

      {/* World map section End */}




      {/* Latest News */}
      <div className="bg-white-A700 flex flex-col items-center justify-end mt-[41px] p-[97px] md:px-10 sm:px-5 w-full">
        <Text
          className="mt-[9px] sm:text-[40px] md:text-[46px] text-[40px] text-center text-gray-800"
          size="txtMontserratBold50Gray800"
        >
          Lates News & Articles
        </Text>
        <Text
          className="mt-[25px] text-center text-gray-900_8e text-[18px]"
          size="txtMontserratMedium20"
        >
          Get the best services at the lowest price
        </Text>
        <List
          className="sm:flex-col flex-row md:gap-10 gap-28 grid sm:grid-cols-1 md:grid-cols-2 grid-cols-3 justify-center max-w-[950px] mt-[82px] mx-auto w-full"
          orientation="horizontal"
        >
          {slide169OneShadowPropList.map((props, index) => (
            <React.Fragment key={`Slide169OneShadow${index}`}>
              <Slide169OneShadow
                className="bg-white-A700 flex flex-col h-[466px] md:h-auto items-start justify-start rounded-[12px] shadow-bs w-[300px]"
                {...props}
              />
            </React.Fragment>
          ))}
        </List>
      </div>
      {/* Latest News */}


      <Footer className="flex items-center justify-center mt-[41px] md:px-5 w-full" />


    </>
  );
};

export default Slide169OnePage;
