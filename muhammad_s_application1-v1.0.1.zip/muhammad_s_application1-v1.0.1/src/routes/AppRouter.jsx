import { Routes, Route, Navigate } from "react-router-dom";
import Slide169One from "../pages/Slide169One/index"
import Slide169Two from "../pages/Slide169Two/index"
import Slide169ThreePage from "../pages/Slide169Three/index"
import FormOnePage from "../pages/FormOne/index"
import FormTwoPage from "../pages/FormTwo/index"
import FormThreePage from "../pages/FormThree/index"
import FormFourPage from "../pages/FormFour/index"
export default function AppRouter() {
  return (
    <Routes>
      <Route path="/" element={<Slide169One/>} />
      <Route path="/about" element={<Slide169Two/>} />
      <Route path="/blog" element={<Slide169ThreePage/>} />
      <Route path="/form-one" element={<FormOnePage/>} />
      <Route path="/form-two" element={<FormTwoPage/>} />
      <Route path="/form-three" element={<FormThreePage/>} />
      <Route path="/form-four" element={<FormFourPage/>} />
      {/* <Route path="/form-one" element={<div>Testing</div>} /> */}
      <Route path="*" element={<Navigate to="/" replace={true} />} />
    </Routes>
  );
}