import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "pages/Home";
import NotFound from "pages/NotFound";
const Slide169Three = React.lazy(() => import("pages/Slide169Three"));
const Slide169Two = React.lazy(() => import("pages/Slide169Two"));
const Slide169One = React.lazy(() => import("pages/Slide169One"));
const ProjectRoutes = () => {
  return (
    <React.Suspense fallback={<>Loading...</>}>
      <Router>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="*" element={<NotFound />} />
          <Route path="/slide169one" element={<Slide169One />} />
          <Route path="/slide169two" element={<Slide169Two />} />
          <Route path="/slide169three" element={<Slide169Three />} />
        </Routes>
      </Router>
    </React.Suspense>
  );
};
export default ProjectRoutes;
