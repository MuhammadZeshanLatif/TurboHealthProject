import React from "react";

const sizeClasses = {
  txtMontserratMedium20: "font-medium font-montserrat",
  txtMontserratRegular15Bluegray90001: "font-montserrat font-normal",
  txtMontserratMedium25: "font-medium font-montserrat",
  txtMontserratMedium24: "font-medium font-montserrat",
  txtPoppinsSemiBold14Gray90002: "font-poppins font-semibold",
  txtMontserratMedium24Gray800: "font-medium font-montserrat",
  txtPoppinsSemiBold14: "font-poppins font-semibold",
  txtMontserratSemiBold30: "font-montserrat font-semibold",
  txtMontserratBold40WhiteA700: "font-bold font-montserrat",
  txtMontserratMedium1973WhiteA700: "font-medium font-montserrat",
  txtMontserratMedium1973: "font-medium font-montserrat",
  txtMontserratBold3382WhiteA700: "font-bold font-montserrat",
  txtMontserratBold2133: "font-bold font-montserrat",
  txtMontserratRegular22Bluegray90001: "font-montserrat font-normal",
  txtMontserratBold20: "font-bold font-montserrat",
  txtMontserratRegular11: "font-montserrat font-normal",
  txtMontserratRegular52: "font-montserrat font-normal",
  txtMontserratBold10176: "font-bold font-montserrat",
  txtMontserratBold393: "font-bold font-montserrat",
  txtMontserratMedium1867: "font-medium font-montserrat",
  txtMontserratMedium25Gray600: "font-medium font-montserrat",
  txtMontserratMedium25WhiteA700: "font-medium font-montserrat",
  txtMontserratRegular12Bluegray700: "font-montserrat font-normal",
  txtPoppinsRegular20: "font-normal font-poppins",
  txtMontserratBold2021: "font-bold font-montserrat",
  txtMontserratBold35: "font-bold font-montserrat",
  txtMontserratBold32: "font-bold font-montserrat",
  txtMontserratRegular22: "font-montserrat font-normal",
  txtMontserratBold20Gray90002: "font-bold font-montserrat",
  txtMontserratRegular20: "font-montserrat font-normal",
  txtMontserratBold1838: "font-bold font-montserrat",
  txtMontserratRegular16: "font-montserrat font-normal",
  txtPoppinsRegular12: "font-normal font-poppins",
  txtMontserratSemiBold1838: "font-montserrat font-semibold",
  txtMontserratBold50Gray800: "font-bold font-montserrat",
  txtSegoeUI12: "font-normal font-segoeui",
  txtMontserratRegular14: "font-montserrat font-normal",
  txtMontserratRegular22WhiteA700: "font-montserrat font-normal",
  txtMontserratRegular15: "font-montserrat font-normal",
  txtMontserratRegular12: "font-montserrat font-normal",
  txtMontserratBold40: "font-bold font-montserrat",
  txtMontserratBold3382: "font-bold font-montserrat",
  txtMontserratRegular24WhiteA700: "font-montserrat font-normal",
  txtMontserratMedium3893: "font-medium font-montserrat",
  txtMontserratRegular1838: "font-montserrat font-normal",
  txtMontserratRegular16Gray9008e: "font-montserrat font-normal",
  txtMontserratMedium1684WhiteA700: "font-medium font-montserrat",
  txtMontserratSemiBold25: "font-montserrat font-semibold",
  txtSegoeUI22: "font-normal font-segoeui",
  txtSegoeUI20: "font-normal font-segoeui",
  txtMontserratSemiBold20: "font-montserrat font-semibold",
  txtMontserratRegular15Blue900: "font-montserrat font-normal",
  txtMontserratRegular24: "font-montserrat font-normal",
  txtMontserratSemiBold1867: "font-montserrat font-semibold",
  txtMontserratMedium1684: "font-medium font-montserrat",
  txtMontserratBold52: "font-bold font-montserrat",
  txtMontserratBold50: "font-bold font-montserrat",
  txtAmsterdamSignature65: "font-amsterdamsignature font-normal",
};

const Text = ({ children, className = "", size, as, ...restProps }) => {
  const Component = as || "p";

  return (
    <Component
      className={`text-left ${className} ${size && sizeClasses[size]}`}
      {...restProps}
    >
      {children}
    </Component>
  );
};

export { Text };
